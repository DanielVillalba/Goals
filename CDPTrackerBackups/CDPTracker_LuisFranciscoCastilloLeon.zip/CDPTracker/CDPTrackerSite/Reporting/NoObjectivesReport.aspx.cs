﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.Reporting.WebForms;
using Utils;
using System.Configuration;
using CDPTrackerSite.RoleManagement;
using System.Data;
using DataSource;
using System.Collections;
using CDPTrackerSite.Models;
using CDPTrackerSite.Controllers;

namespace CDPTrackerSite.Reporting
{
    public partial class NoObjectivesReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string year = Request.QueryString["year"];
                string quarter = Request.QueryString["quarter"];

                List<NoObjectivesReportModel> employeesWithoutObjectives = getEmployeesWithoutObjectives(Convert.ToInt32(year),Convert.ToInt32(quarter));
                report.LocalReport.DataSources.Add(new ReportDataSource("noObjectivesList", employeesWithoutObjectives));
                report.LocalReport.ReportPath = Server.MapPath("~/Reporting/NoObjectivesReport.rdlc");
            }
        }

        public static List<NoObjectivesReportModel> getEmployeesWithoutObjectives(Nullable<int> year, Nullable<int> quarter)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {

                EmployeeActiveDirectoryManager employeeActiveDirectoryManager = GoalTrackingController.getActiveDirectoryInstance();
                List<EmployeeActiveDirectoryManager.UserData> userData = employeeActiveDirectoryManager.GetUserList();


                const int UNASSIGNED_OBJECTIVE_CATEGORY_ID = 4;

                List<int> objectives = new List<int>();

                if (year != 0 && quarter != 0)
                {
                    objectives = context.Objectives.Where(
                        x => x.CategoryId != UNASSIGNED_OBJECTIVE_CATEGORY_ID
                        && x.Year == year && x.Quarter == quarter
                        ).Select(x => x.ResourceId).ToList();
                }
                else {
                    objectives = context.Objectives.Where(x => x.CategoryId != UNASSIGNED_OBJECTIVE_CATEGORY_ID).Select(x => x.ResourceId).ToList();
                }
                

                //Obtener Resources
                var resources = context.Resources.Select(x => new { x.ResourceId }).ToList();

                //employees With
                var employeesIDWithoutObjectives = resources.Where(x => !objectives.Contains(x.ResourceId)).Select(x => x.ResourceId);


                int val = employeesIDWithoutObjectives.Count();



                List<NoObjectivesReportModel> employeesWithoutObjectives = new List<NoObjectivesReportModel>();


                foreach (var id in employeesIDWithoutObjectives)
                {
                    NoObjectivesReportModel employee = context.Resources.Where(x => x.ResourceId == id).Select(x =>
                        new NoObjectivesReportModel { 
                           ResourceId=x.ResourceId,
                           Lastlogin=x.LastLogin,
                           Name=x.Name,
                           DomainName= x.DomainName
                        }).FirstOrDefault();

                    employee.Manager = GetManagerR(employee.DomainName, userData);

                    if (GoalTrackingController.ExclusionList.Any(x => x.Contains(employee.DomainName)))
                        continue;

                    if (GoalTrackingController.GetIfIsActiveEmployeeFromAD(employee.DomainName))
                        employeesWithoutObjectives.Add(employee);
                }

                return employeesWithoutObjectives.OrderBy(x=>x.Name).ToList();
            }
        }




        public static bool IsEnabledR(string domainName, IEnumerable<EmployeeActiveDirectoryManager.UserData> userData)
        {
 
            EmployeeActiveDirectoryManager.UserData user = userData.SingleOrDefault(u => string.Compare(u.DomainName, domainName, StringComparison.OrdinalIgnoreCase) == 0);
            if (user == null)
            {
                return false;
            }

            return
                !user.OperationalUnits.Any(
                    ou =>
                    Constants.ExcludedOperationUnits.Any(eou => string.Compare(ou, eou, StringComparison.OrdinalIgnoreCase) == 0));
        }


        public static string GetManagerR(string domainName, IEnumerable<EmployeeActiveDirectoryManager.UserData> userDataList)
        {
            string managerName = userDataList.Where(u => string.Compare(u.DomainName, domainName, StringComparison.OrdinalIgnoreCase) == 0).Select(u => u.Manager).FirstOrDefault();
            if (managerName == null) return string.Empty;

            return managerName.GetNameFromCommonNameMatch();
        }
    }
}