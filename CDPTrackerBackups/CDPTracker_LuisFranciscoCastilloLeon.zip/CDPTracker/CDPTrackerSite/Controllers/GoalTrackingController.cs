﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using System.Web.Mvc;
using CDPTrackerSite.DataAccessor;
// ReSharper disable RedundantUsingDirective ==> Directive is used when application is in Release mode 
using CDPTrackerSite.RoleManagement;
using CDPTrackerSite.Models;
// ReSharper restore RedundantUsingDirective

using DataSource;
using Utils;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.Globalization;
using System.Configuration;
using System.DirectoryServices;
using System.Collections;
using System.IO;
using System.Data.Entity.Validation;
using System.Net.Sockets;



namespace CDPTrackerSite.Controllers
{
    public enum ProgressEnumeration
    {
        NotStarted = 0,
        InProgress = 1,
        Completed = 2,
    }

    public class GoalTrackingController : Controller
    {
        private const string SessionUserManagerName = "ManagerName";
        private const string SessionCurrentPosition = "CurrentPosition";
        private static EmployeeActiveDirectoryManager activeDirectoryInstance;

        /***********************************************************  Region for Helpers Methods*********************************************/
        #region Helpers

        public static IEnumerable<string> ExclusionList = new List<string>
        {
            "Cliff Schertz",
            "itsupport",
            "Maria Pena"
        };

        public static EmployeeActiveDirectoryManager getActiveDirectoryInstance()
        {
            //SINGLETON PATTERN
            if (activeDirectoryInstance == null)
            {
                string activeDirectoryPath = ConfigurationManager.AppSettings["ADPath"];
                string activeDirectoryUser = ConfigurationManager.AppSettings["ADUsr"];
                string activeDirectoryPass = ConfigurationManager.AppSettings["ADPass"];
                activeDirectoryInstance = new EmployeeActiveDirectoryManager(activeDirectoryPath, activeDirectoryUser, activeDirectoryPass);
            }

            return activeDirectoryInstance;
        }

        public int? GetActiveDirectoryId()
        {
            Resource resource;
            ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource);

            if (resource.ActiveDirectoryId == null)
            {
                return 0;
            }
            else
            {
                return resource.ActiveDirectoryId;
            }
        }

        private string GetCurrentUserManagerName()
        {
            string currentUserManagerName = Session[SessionUserManagerName] as string;
            if (currentUserManagerName != null)
            {
                return currentUserManagerName;
            }

            string managerName = ResourceDataAccessor.GetManagerName(User.Identity.Name.StripDomain());
            Session[SessionUserManagerName] = managerName;

            return managerName;
        }

        public string GetCurrentPositionFromAD()
        {
            string currentPosition = Session[SessionCurrentPosition] as string;
            if (currentPosition != null)
            {
                return currentPosition;
            }

            currentPosition = ResourceDataAccessor.GetCurrentPositionFromAD(User.Identity.Name.StripDomain());
            Session[SessionCurrentPosition] = currentPosition;

            return currentPosition;
        }

        public void BaseViewBagSetup()
        {
            ViewBag.ManagerName = GetCurrentUserManagerName();
            ViewBag.CurrentPositionFromAD = GetCurrentPositionFromAD();

#if !DEBUG
            ViewBag.IsManager = RoleManagementHelper.UserIsInRole(User, Role.Manager);
            ViewBag.IsTalentManagementResource = RoleManagementHelper.UserIsInRole(User, Role.TalentManagement);
#else

            ViewBag.IsManager = true;
            ViewBag.IsTalentManagementResource = true;
#endif
        }

        public void SetupCommonViewBagValues()
        {
            BaseViewBagSetup();
            if (ViewBag.IsManager != true) return;

            ViewBag.PendingGoalsCount = GetManagerPendingGoalsCount();
        }

        private void SetupCommonViewBagValues(int pendingGoalsCount)
        {
            BaseViewBagSetup();
            if (ViewBag.IsManager != true) return;

            ViewBag.PendingGoalsCount = pendingGoalsCount;
        }

        protected string GetManager(string domainName, IEnumerable<EmployeeActiveDirectoryManager.UserData> userDataList)
        {
            string managerName = userDataList.Where(u => string.Compare(u.DomainName, domainName, StringComparison.OrdinalIgnoreCase) == 0).Select(u => u.Manager).FirstOrDefault();
            if (managerName == null) return string.Empty;

            return managerName.GetNameFromCommonNameMatch();
        }

        private int GetManagerPendingGoalsCount()
        {
            // ReSharper disable RedundantAssignment
            string managerName = User.Identity.Name.StripDomain();
            // ReSharper restore RedundantAssignment

#if DEBUG
            managerName = "rafael durazo";
#endif
            Resource manager;
            if (!ResourceDataAccessor.TryGetResourceByUserName(managerName, out manager))
            {
                return 0;
            }

            List<Resource> managerResources;
            if (!ResourceDataAccessor.TryGetVerifiableResourcesFromManager(managerName, out managerResources))
            {
                return 0;
            }

            int goalCount = GetGoalsCountFromManagerResources(managerResources);
            return goalCount;
        }

        private IEnumerable<ProgressEnum> GetProgresEnums()
        {
            const string sessionProgressEnums = "ProgressEnums";
            IEnumerable<ProgressEnum> progressEnums = Session[sessionProgressEnums] as IEnumerable<ProgressEnum>;
            if (progressEnums != null) return progressEnums;

            if (!ResourceDataAccessor.TryGetProgresEnums(out progressEnums))
            {
                return new List<ProgressEnum>();
            }

            Session[sessionProgressEnums] = progressEnums;
            return progressEnums;
        }

        private IEnumerable<Location> GetLocation()
        {
            const string sessionLocationEnums = "LocationEnums";
            IEnumerable<Location> locationEnums = Session[sessionLocationEnums] as IEnumerable<Location>;
            if (locationEnums != null) return locationEnums;

            if (!ResourceDataAccessor.TryGetLocations(out locationEnums))
            {
                return new List<Location>();
            }

            Session[sessionLocationEnums] = locationEnums;
            return locationEnums;
        }

        private IEnumerable<GeneralTrainingProgram> GetGeneralTraining()
        {
            //const string sessionGeneralTrainingEnums = "GeneralTrainingEnums";
            //IEnumerable<GeneralTrainingProgram> generalTrainingEnums = Session[sessionGeneralTrainingEnums] as IEnumerable<GeneralTrainingProgram>;
            //if (generalTrainingEnums != null) return generalTrainingEnums;
            IEnumerable<GeneralTrainingProgram> generalTrainingPrograms = new List<GeneralTrainingProgram>();
            if (!ResourceDataAccessor.TryGetGeneralTrainings(out generalTrainingPrograms))
            {
                return new List<GeneralTrainingProgram>();
            }

            //Session[sessionGeneralTrainingEnums] = generalTrainingEnums;
            return generalTrainingPrograms;
        }

        private IEnumerable<Category> GetCategory()
        {
            const string sessionCategory = "categoryEnums";
            IEnumerable<Category> categoryEnums = Session[sessionCategory] as IEnumerable<Category>;
            if (categoryEnums != null) return categoryEnums;

            if (!ResourceDataAccessor.TryGetCategories(out categoryEnums))
            {
                return categoryEnums;
            }

            return categoryEnums;
        }

        private IEnumerable<Area> GetArea()
        {
            const string sessionArea = "areaEnums";
            IEnumerable<Area> areaEnums = Session[sessionArea] as IEnumerable<Area>;
            if (areaEnums != null) return areaEnums;

            if (!ResourceDataAccessor.TryGetAreas(out areaEnums))
            {
                return areaEnums;
            }

            return areaEnums.Where(x => x.AreaId > 0);
        }

        private IEnumerable<Objective> GetObjective(int ResourceId)
        {
            const string sessionObjective = "objectiveEnums";
            IEnumerable<Objective> objectiveEnums = Session[sessionObjective] as IEnumerable<Objective>;
            if (objectiveEnums != null) return objectiveEnums;

            if (!ResourceDataAccessor.TryGetObjectives(ResourceId, out objectiveEnums))
            {
                return objectiveEnums;
            }

            return objectiveEnums;
        }

        private IEnumerable<Position> GetPosition()
        {
            const string sessionPosition = "positionEnums";
            IEnumerable<Position> positionEnums = Session[sessionPosition] as IEnumerable<Position>;
            if (positionEnums != null) return positionEnums;

            if (!ResourceDataAccessor.TryGetPositions(out positionEnums))
            {
                return positionEnums;
            }

            return positionEnums;
        }

        private IEnumerable<Technologies> GetTechnology()
        {
            const string sessionTechnology = "technologyEnums";
            IEnumerable<Technologies> technologyEnums = Session[sessionTechnology] as IEnumerable<Technologies>;
            if (technologyEnums != null) return technologyEnums;

            if (!ResourceDataAccessor.TryGetTechnologies(out technologyEnums))
            {
                return technologyEnums;
            }

            return technologyEnums;
        }

        private IEnumerable<Level> GetLevel()
        {
            const string sessionLevel = "levelEnums";
            IEnumerable<Level> levelEnums = Session[sessionLevel] as IEnumerable<Level>;
            if (levelEnums != null) return levelEnums;

            if (!ResourceDataAccessor.TryGetLevels(out levelEnums))
            {
                return levelEnums;
            }

            return levelEnums;
        }

        public static int GetPositionID(string position)
        {
            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var currentPosition = context.Position.Where(a => a.PositionName == position).FirstOrDefault();
                    int idNewPosition = currentPosition.PositionId;

                    return idNewPosition;
                }
            }
            catch (NullReferenceException)
            { }

            return 0;
        }

        private int GetGoalsCountFromManagerResources(IEnumerable<Resource> managerResources)
        {
            int goalCount = managerResources.Where(r => r.Employee != null).Sum(r => r.Employee.Resource.GoalTrackings.Count());
            return goalCount;
        }

        public static ExpandoObject ToExpando(object anonymousObject)
        {
            IDictionary<string, object> anonymousDictionary = HtmlHelper.AnonymousObjectToHtmlAttributes(anonymousObject);
            IDictionary<string, object> expando = new ExpandoObject();
            foreach (var item in anonymousDictionary)
                expando.Add(item);
            return (ExpandoObject)expando;
        }

        public static int getPercentage(int resourceId)
        {
            const int COMPLETED_GOAL_ENUM = 2;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                try
                {
                    int year = DateTime.Now.Year;
                    //int year = 2014;
                    var allGoals = context.GoalTrackings.Include("Objective").Where(x => x.ResourceId == resourceId && x.Objective.Year == year);
                    int allGoalsCount = allGoals.Count();

                    var goalsCompleted = allGoals.Where(x => x.Progress == COMPLETED_GOAL_ENUM);
                    int goalsCompletedCount = goalsCompleted.Count();

                    decimal allGoalsCountDecimal = Convert.ToDecimal(allGoalsCount);
                    decimal goalsCompletedCountDecimal = Convert.ToDecimal(goalsCompletedCount);

                    decimal result = Decimal.Divide(goalsCompletedCountDecimal, allGoalsCountDecimal) * 100;

                    return Convert.ToInt32(result);
                }
                catch (DivideByZeroException)
                {
                    return 0;
                }
            }
        }
        public static int getGoalsCompletedCount(int ResourceId)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                int year = DateTime.Now.Year;
                var allGoals = context.GoalTrackings.Include("Objective").Where(x => x.ResourceId == ResourceId && x.Objective.Year == year);
                int allGoalsCount = allGoals.Count();
                var goalsCompleted = allGoals.Where(x => x.Progress == 2);
                return goalsCompleted.Count();
            }
        }

        public void getTeammates(int ResourceId)
        {
            if (Session["HallOfFame"] == null)
            {
                List<Employee> teammates = new List<Employee>();
                List<dynamic> hallOfFame = new List<dynamic>();
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    int? projectId = context.Employee.Where(x => x.ResourceId == ResourceId).Select(x => x.ProjectId).FirstOrDefault();
                    if (projectId != null)
                    {
                        teammates = context.Employee.Where((x => x.ProjectId == projectId)).ToList();
                        teammates.RemoveAll(x => !GetIfIsActiveEmployeeFromAD(x.Resource.DomainName));
                    }
                    foreach (Employee employee in teammates)
                    {
                        hallOfFame.Add(new
                        {
                            Name = employee.Resource.Name,
                            ActiveDirectoryId = employee.Resource.ActiveDirectoryId,
                            Percent = getPercentage(employee.ResourceId),
                            GoalCompletedCount = getGoalsCompletedCount(employee.ResourceId)
                        });
                    }
                    var result = (from n in hallOfFame orderby n.Percent descending, n.GoalCompletedCount descending select n).Take(3);
                    var finalResult = new List<ExpandoObject>();
                    foreach (var teammate in result.ToList())
                    {
                        finalResult.Add(ToExpando(teammate));
                    }
                    Session["HallOfFame"] = finalResult;
                }
            }
        }

        public static int getPercentageVerified(int resourceId)
        {
            const int COMPLETED_GOAL_ENUM = 2;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                try
                {
                    int year = DateTime.Now.Year;

                    var allGoals = context.GoalTrackings.Include("Objective").Where(x => x.ResourceId == resourceId && x.Objective.Year == year);
                    int allGoalsCount = allGoals.Count();

                    var goalsCompleted = allGoals.Where(x => x.Progress == COMPLETED_GOAL_ENUM && x.VerifiedByManager == true);
                    int goalsCompletedCount = goalsCompleted.Count();

                    decimal allGoalsCountDecimal = Convert.ToDecimal(allGoalsCount);
                    decimal goalsCompletedCountDecimal = Convert.ToDecimal(goalsCompletedCount);

                    decimal result = Decimal.Divide(goalsCompletedCountDecimal, allGoalsCountDecimal) * 100;

                    return Convert.ToInt32(result);
                }
                catch (DivideByZeroException)
                {
                    return 0;
                }
            }
        }

        public static bool GetIfIsActiveEmployeeFromAD(string logonName)
        {
            EmployeeActiveDirectoryManager ActiveDirectory = getActiveDirectoryInstance();
            IList<String> OUFromEmployee;

            try
            {
                //if employee is part of an OU different from Ex-User Or Customers then is an ActiveEmployee.
                OUFromEmployee = ActiveDirectory.GetEmployeeOrganizationalUnitList(logonName).ToList();

                foreach (var OU in OUFromEmployee)
                {
                    if (OU.Equals("Ex-User") || OU.Equals("Customers") || OU.Equals("Interns"))
                        return false;
                }
            }
            catch (ArgumentException e)
            {
                return false;
            }

            return (OUFromEmployee.Count > 0);
        }

        private bool SendEmail(string emailAddress, string emailBody, string subject)
        {
            bool isEmailSent;

            MailAddress to = new MailAddress(emailAddress);
            MailAddress from = new MailAddress("tm@tiempodevelopment.com");
            MailMessage mail = new MailMessage(from, to)
            {
                Subject = subject,
                IsBodyHtml = true,
                Body = emailBody
            };

            string emailTarget = emailAddress;
            try
            {
                using (SmtpClient smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    UseDefaultCredentials = true,
                    Credentials = new NetworkCredential("tiempotm@gmail.com", "Ti3mpoTalent")
                })
                {
                    smtp.Send(mail);
                }
                Console.WriteLine("Mail Sent to: " + emailTarget);
                isEmailSent = true;
            }
            catch (SmtpException)
            {
                Console.WriteLine("Failure to send email to " + emailTarget);
                isEmailSent = false;
            }
            //write the result of the email send attempt to a log file
            string fileName = DateTime.Today.Year.ToString(CultureInfo.InvariantCulture) + "-" + DateTime.Today.Month.ToString(CultureInfo.InvariantCulture) + ".log";
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(fileName, true))
            {
                if (isEmailSent)
                {
                    file.WriteLine(DateTime.Now + " Succesfully email sent to: " + emailTarget);
                }
                else
                {
                    file.WriteLine(DateTime.Now + " Failure sending email to: " + emailTarget);
                }
            }
            return isEmailSent;
        }

        [HttpPost]
#if !DEBUG
        [ComplexRoleAuthorization(Role.Manager, Role.TalentManagement)]
#endif
        public ActionResult SendMailToEmployeesWithNoObjectives()
        {
            List<NoObjectivesReportModel> employeesWithoutObjectives = Reporting.NoObjectivesReport.getEmployeesWithoutObjectives(null,null);

            string subject = "CDPTracker - Objectives have not been created";

            string body = "Hello {0},<br> We have noticed that you still haven't created objectives in this period. " +
                          "Please go ahead make this list so you can track your progress and keep a record of your achievements.<br>" +
                          "Sincerely,<br>Talent Management Team<br>Collaborating with you to achieve your professional aspirations.";

            EmployeeActiveDirectoryManager ActiveDirectory = getActiveDirectoryInstance();

            foreach (var resource in employeesWithoutObjectives)
            {
                string email = ActiveDirectory.GetUserPropertyValue(resource.DomainName, "mail");
#if DEBUG
                email = "lcastillo@tiempodevelopment.com";
#endif
                SendEmail(email, string.Format(body, resource.Name), subject);
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
#if !DEBUG
        [ComplexRoleAuthorization(Role.Manager, Role.TalentManagement)]
#endif
        public ActionResult SendMailToEmployeesWithUnassignObjectives()
        {
            List<dynamic> employeesWithUnassignObjectives = Reporting.UnassignObjectiveReport.getEmployeesWithUnassignObjectives();

            string subject = "CDPTracker - goals have not been linked to your objectives";

            string body = "Hello, <br> We have noticed that you still haven't linked goals to objectives in this period. " +
                          "Please go ahead and fill these lists so you can track your progress and keep a record of your achievements.<br>" +
                          "Sincerely,<br>Talent Management Team<br>Collaborating with you to achieve your professional aspirations.";

            EmployeeActiveDirectoryManager ActiveDirectory = getActiveDirectoryInstance();

            foreach (dynamic resource in employeesWithUnassignObjectives)
            {
                string email = ActiveDirectory.GetUserPropertyValue(resource.DomainName, "mail");
#if DEBUG
                email = "lcastillo@tiempodevelopment.com";
#endif
                SendEmail(email, body, subject);
            }


            return RedirectToAction("/UnassignObjectiveReport");
        }

        public int GetCurrentYear()
        {
            DateTime? date = DateTime.Now;
            return date.Value.Year;
        }

        public void ListOfYears()
        {
            try
            {
                List<SelectListItem> dropdownItems = new List<SelectListItem>();

                for (int i = 0; i <= 20; i++)
                {
                    int Year = (GetCurrentYear() + 2) - i;

                    dropdownItems.AddRange(new[] { new SelectListItem() { Text = Year.ToString(), Value = Year.ToString() } });
                }

                ViewBag.ListOfYears = dropdownItems;
            }
            catch (Exception)
            { }
        }

        public List<SelectListItem> GetQuarter()
        {
            List<SelectListItem> lstQuarter = new List<SelectListItem>();
            lstQuarter.Add(new SelectListItem { Text = "Jan - Mar", Value = "1" });
            lstQuarter.Add(new SelectListItem { Text = "Apr - June", Value = "2" });
            lstQuarter.Add(new SelectListItem { Text = "July - Sept", Value = "3" });
            lstQuarter.Add(new SelectListItem { Text = "Oct - Dec", Value = "4" });

            return lstQuarter;
        }

        public Int32 GetActualQuarter()
        {
            int month = DateTime.Now.Month;
            int quarter = 0;

            if (month >= 1 && month <= 3)
            {
                quarter = 1;
            }
            else if (month >= 4 && month <= 6)
            {
                quarter = 2;
            }
            else if (month >= 7 && month <= 9)
            {
                quarter = 3;
            }
            else if (month >= 10 && month <= 12)
            {
                quarter = 4;
            }

            return quarter;
        }

        #endregion

        /***********************************************************  Region for Action Results of "Personal Evaluation" ********************/
        #region Personal Evaluation

        #region Objectives
        //
        // GET: /GoalTracking/
        public ActionResult Index()
        {
            Resource resource;
            ListOfYears();
            ViewBag.Year = GetCurrentYear();
            ViewBag.ListOfQuarters = new SelectList(GetQuarter(), "Value", "Text", GetActualQuarter());

            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
            {
                TempData[ResourceController.IsRedirectBycode] = true;
                return RedirectToAction("SetupResourceData", "Resource");
            }


            resource.GoalTrackings = resource.GoalTrackings
                                             .OrderBy(goal => goal.FinishDate.HasValue ? goal.FinishDate.Value : DateTime.MinValue).ToList();


            resource.Objective = resource.Objective.Where(obj => obj.Year == GetCurrentYear() && obj.Quarter == GetActualQuarter() || obj.Year == null || obj.Quarter == null)
                                         .OrderBy(obj => obj.CategoryId).ToList();



            ViewBag.PercentageCompleted = getPercentage(resource.ResourceId);
            ViewBag.PercentageVerified = getPercentageVerified(resource.ResourceId);
            ViewBag.ActiveDirectoryId = resource.ActiveDirectoryId;
            ViewBag.Position = resource.Employee.CurrentPosition;
            ViewBag.AspiringPosition = resource.Employee.AspiringPosition;
            ViewBag.Name = resource.Name;
            ViewBag.ResourceId = resource.ResourceId;

            SetupCommonViewBagValues();

            getTeammates(resource.ResourceId);

            return View(resource);
        }

        [HttpPost]
        public ActionResult Index(Resource resource)
        {
            int Year = GetCurrentYear();
            int.TryParse(Request.Form["Year"].ToString(), out Year);

            int Quarter = GetActualQuarter();
            int.TryParse(Request.Form["Quarter"].ToString(), out Quarter);

            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
            {
                TempData[ResourceController.IsRedirectBycode] = true;
                return RedirectToAction("SetupResourceData", "Resource");
            }

            resource.GoalTrackings = resource.GoalTrackings
                                                .OrderBy(goal => goal.FinishDate.HasValue ? goal.FinishDate.Value : DateTime.MinValue).ToList();
            resource.Objective = resource.Objective.Where(obj => obj.Year == Year && obj.Quarter == Quarter)
                                            .OrderBy(obj => obj.CategoryId).ToList();
            ListOfYears();
            ViewBag.ListOfQuarters = new SelectList(GetQuarter(), "Value", "Text");
            ViewBag.Year = Year;
            ViewBag.Quarter = Quarter;
            ViewBag.PercentageCompleted = getPercentage(resource.ResourceId);
            ViewBag.PercentageVerified = getPercentageVerified(resource.ResourceId);
            ViewBag.ActiveDirectoryId = resource.ActiveDirectoryId;
            ViewBag.Position = resource.Employee.CurrentPosition;
            ViewBag.AspiringPosition = resource.Employee.AspiringPosition;
            ViewBag.Name = resource.Name;
            ViewBag.ResourceId = resource.ResourceId;

            SetupCommonViewBagValues();

            return View(resource);
        }

        public ActionResult PositionEdit()
        {
            Resource resource;
            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
            {
                return RedirectToAction("Index");
            }

            string currentPosition = GetCurrentPositionFromAD();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {


                Position positionObject = (from position in context.Position where currentPosition.Equals(position.PositionName) select position).FirstOrDefault();

                var optionsForDropDownList = (from positionHierarchy in context.PositionsHierarchy
                                              join position in context.Position
                                              on positionHierarchy.PositionId equals position.PositionId
                                              where positionHierarchy.PositionId == positionObject.PositionId
                                              select new { Text = positionHierarchy.Position1.PositionName, Value = positionHierarchy.Position1.PositionName }).ToList();

                SelectList nextPositionsAvailable = new SelectList(optionsForDropDownList, "Value", "Text");
                ViewBag.NextPositions = nextPositionsAvailable;
            }

            SetupCommonViewBagValues();
            Employee employee = resource.Employee ?? new Employee { ResourceId = resource.ResourceId };

            employee.CurrentPosition = currentPosition;
            return View(employee);
        }

        [HttpPost]
        public ActionResult PositionEdit(Employee employee)
        {
            employee.AspiringPositionID = GetPositionID(employee.AspiringPosition);

            if (ModelState.IsValid)
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    if (context.Employee.Any(e => e.ResourceId == employee.ResourceId))
                    {
                        context.Entry(employee).State = EntityState.Modified;
                    }
                    else
                    {
                        context.Entry(employee).State = EntityState.Added;
                    }
                    try
                    {
                        context.SaveChanges();
                    }
                    catch (Exception e)
                    { }
                }
                return RedirectToAction("Index");
            }

            return View();
        }

        public ActionResult BulkEdit(int ObjectiveId, int ResourceId)
        {
            ViewBag.ProgressList = new SelectList(GetProgresEnums(), "Id", "Label");
            ViewBag.ObjectiveList = new SelectList(GetObjective(ResourceId), "ObjectiveId", "Objective1");

            Resource resource;
            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
            {
                return RedirectToAction("Index");
            }

            if (ObjectiveId != 0)
            {
                resource.GoalTrackings = resource.GoalTrackings.Where(goal => goal.ObjectiveId == ObjectiveId && goal.VerifiedByManager != true).
                                         OrderBy(goal => goal.FinishDate.HasValue ? goal.FinishDate.Value : DateTime.MinValue).ToList();
            }
            else
            {
                resource.GoalTrackings = resource.GoalTrackings.Where(goal => goal.ObjectiveId == null && goal.VerifiedByManager != true).
                                         OrderBy(goal => goal.FinishDate.HasValue ? goal.FinishDate.Value : DateTime.MinValue).ToList();
            }

            ViewBag.IsResourceAvailable = true;

            SetupCommonViewBagValues();
            return View(resource);
        }

        [HttpPost]
        public ActionResult BulkEdit(Resource resource)
        {
            bool isUpdated = false;

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    //we only care for those Goals that have not yet been verified; all others cannot be edited
                    List<GoalTracking> resourceGoalTrackings = context.GoalTrackings.Where(g => g.ResourceId == resource.ResourceId && !g.VerifiedByManager).ToList();

                    foreach (var goalTracking in resource.GoalTrackings.Where(g => !g.VerifiedByManager))
                    {
                        GoalTracking original = resourceGoalTrackings.SingleOrDefault(g => g.GoalId == goalTracking.GoalId);

                        if (original == null || (original.Goal == goalTracking.Goal
                                                 && original.ObjectiveId == goalTracking.ObjectiveId
                                                 && original.Progress == goalTracking.Progress
                                                 && original.FinishDate == goalTracking.FinishDate))
                            continue;

                        goalTracking.LastUpdate = DateTime.Now;
                        context.Entry(original).CurrentValues.SetValues(goalTracking);
                        isUpdated = true;
                    }
                    if (isUpdated)
                        context.SaveChanges();
                }
            }
            catch (Exception)
            { }

            return RedirectToAction("Index");
        }

        //
        // GET: /GoalTracking/Create

        public ActionResult Create(int id, int ObjectiveId)
        {
            SetupCommonViewBagValues();

            var model = new GoalTracking { ResourceId = id, ObjectiveId = ObjectiveId };
            return View(model);
        }

        //
        // POST: /GoalTracking/Create

        [HttpPost]
        public ActionResult Create(GoalTracking goalTracking)
        {
            if (ModelState.IsValid)
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    goalTracking.LastUpdate = DateTime.Now;
                    context.GoalTrackings.Add(goalTracking);
                    context.SaveChanges();
                }
                return RedirectToAction("Index");
            }

            ViewBag.Progress = new SelectList(GetProgresEnums(), "Id", "Label", goalTracking.Progress);
            return View(goalTracking);
        }

        // GET: /GoalTracking/CreateObjective

        public ActionResult CreateObjective(int id)
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfCategories = new SelectList(GetCategory(), "CategoryId", "Category1");
            ViewBag.ListOfQuarters = new SelectList(GetQuarter(), "Value", "Text", GetActualQuarter());
            ListOfYears();


            var model = new Objective { ResourceId = id };
            return View(model);

        }

        // POST: /GoalTracking/CreateObjective

        [HttpPost]
        public ActionResult CreateObjective(Objective objective)
        {
            if (ModelState.IsValid)
            {

                //Save Object
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    objective.Progress = 0;
                    context.Objectives.Add(objective);
                    context.SaveChanges();
                }



                return RedirectToAction("Index");
            }

            return View(objective);
        }

        // GET: /GoalTracking/EditObjective
        public ActionResult EditObjective(int id)
        {
            SetupCommonViewBagValues();

            Objective objective;
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                objective = context.Objectives.Find(id);
            }
            ViewBag.ListOfCategories = new SelectList(GetCategory(), "CategoryId", "Category1");
            ViewBag.ListOfQuarters = new SelectList(GetQuarter(), "Value", "Text", GetActualQuarter());
            ViewBag.Progress = new SelectList(GetProgresEnums(), "Id", "Label", objective.Progress);
            ListOfYears();

            return View(objective);
        }

        // POST: /GoalTracking/EditObjective
        [HttpPost]
        public ActionResult EditObjective(Objective objective)
        {
            SetupCommonViewBagValues();
            if (ModelState.IsValid)
            {

                using (CDPTrackEntities context = new CDPTrackEntities())
                {

                    //Edit Object

                    context.Entry(objective).State = EntityState.Modified;
                    context.SaveChanges();

                    return RedirectToAction("Index");
                }
            }
            return View(objective);
        }


        // GET: /GoalTracking/DeleteObjective

        public ActionResult DeleteObjective(int id)
        {
            SetupCommonViewBagValues();

            Objective objective;
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                context.Configuration.LazyLoadingEnabled = false;
                objective = context.Objectives.Include("GoalTracking").Include("Category").FirstOrDefault(r => r.ObjectiveId == id);
            }

            return View(objective);
        }

        //
        // POST: /GoalTracking/DeleteObjective/

        [HttpPost, ActionName("DeleteObjective")]
        public ActionResult DeleteObjectiveConfirmed(int id)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                Objective objective = context.Objectives.Find(id);

                if (objective.GoalTracking.Count == 0)
                {
                    context.Objectives.Remove(objective);
                    context.SaveChanges();
                }

                return RedirectToAction("Index");
            }
        }

        //
        // GET: /GoalTracking/Edit/5

        public ActionResult Edit(int GoalId, int ResourceId)
        {
            SetupCommonViewBagValues();

            GoalTracking goalTracking;
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                goalTracking = context.GoalTrackings.Find(GoalId);
            }

            ViewBag.ListOfObjectives = new SelectList(GetObjective(ResourceId), "ObjectiveId", "Objective1");
            ViewBag.Progress = new SelectList(GetProgresEnums(), "Id", "Label", goalTracking.Progress);

            return View(goalTracking);
        }

        //
        // POST: /GoalTracking/Edit/5

        [HttpPost]
        public ActionResult Edit(GoalTracking goalTracking)
        {
            if (ModelState.IsValid)
            {
                goalTracking.LastUpdate = DateTime.Now;
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Entry(goalTracking).State = EntityState.Modified;
                    context.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            ViewBag.Progress = new SelectList(GetProgresEnums(), "Id", "Label", goalTracking.Progress);
            return View(goalTracking);
        }

        //
        // GET: /GoalTracking/Delete/5

        public ActionResult Delete(int id)
        {
            SetupCommonViewBagValues();

            GoalTracking goalTracking;
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                goalTracking = context.GoalTrackings.Include("ProgressEnum").FirstOrDefault(g => g.GoalId == id);
            }
            return View(goalTracking);
        }

        //
        // POST: /GoalTracking/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                GoalTracking goalTracking = context.GoalTrackings.Find(id);
                context.GoalTrackings.Remove(goalTracking);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        #endregion

        #region SelfAssessment
#if !DEBUG
        
#endif
        public ActionResult SelfAssessment()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                Resource resource;
                if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
                {
                    TempData[ResourceController.IsRedirectBycode] = true;
                    return RedirectToAction("SetupResourceData", "Resource");
                }
                int ActualQuarter = GetActualQuarter();
                int ActualYear = DateTime.Now.Year;
                List<Objective> assessmentList = context.Objectives.Where(x => x.ResourceId == resource.ResourceId).ToList();


                // List of shortTerm assesments  (Short is current 0-6 months)
                List<Objective> shortTermList = null;
                if (ActualQuarter != 4)
                {
                    shortTermList = assessmentList.Where(x => (x.Quarter == ActualQuarter && x.Year == ActualYear) || (x.Quarter == ActualQuarter + 1 && x.Year == ActualYear)).ToList();
                }
                else
                {
                    // List of all assessments
                    shortTermList = assessmentList.Where(x => (x.Quarter == ActualQuarter && x.Year == ActualYear) || (x.Quarter == 1 && x.Year == (ActualYear + 1))).ToList();
                }


                // List of long assesments (Long term is 18 months and beyond
                List<Objective> longTermList = assessmentList.Where(x => x.Quarter >= ActualQuarter && x.Year == (ActualYear + 2)).ToList();


                //exclude Elements from long term and short term
                // List of middle assesments  (Middle term is 6-18 months)

                List<Objective> middleTermList = assessmentList.Except(longTermList).Except(shortTermList).ToList();
                List<Objective> submiddleTermList = middleTermList.Where(x => x.Quarter < ActualQuarter && x.Year == ActualYear).ToList();
                middleTermList = middleTermList.Except(submiddleTermList).ToList();


                var models = new Tuple<IEnumerable<Objective>, IEnumerable<Objective>, IEnumerable<Objective>>(shortTermList, middleTermList, longTermList);

                ViewBag.ResourceId = resource.ResourceId;

                return View(models);
            }
        }

#if !DEBUG
        
#endif
        //public ActionResult DeleteAssessment(int idAssessment)
        //{
        //    SetupCommonViewBagValues();

        //    using (CDPTrackEntities context = new CDPTrackEntities())
        //    {
        //        if (isHisAssessment(idAssessment))
        //        {
        //            Assessment assessmentToDelete = context.Assessment.Include("TermProperty").Where(x => x.AssessmentId == idAssessment).FirstOrDefault();
        //            return View(assessmentToDelete);
        //        }

        //        return RedirectToAction("SelfAssessment");
        //    }
        //}

#if !DEBUG
        
#endif
        //[HttpPost]
        //public ActionResult DeleteAssessmentConfirmed(int AssessmentId)
        //{
        //    SetupCommonViewBagValues();

        //    using (CDPTrackEntities context = new CDPTrackEntities())
        //    {
        //        Assessment assessment = context.Assessment.Find(AssessmentId);
        //        context.Assessment.Remove(assessment);
        //        context.SaveChanges();

        //        return RedirectToAction("SelfAssessment");
        //    }
        //}

#if !DEBUG
        
#endif
        //public ActionResult EditAssessment(int IdAssessment)
        //{
        //    SetupCommonViewBagValues();
        //    if (isHisAssessment(IdAssessment))
        //    {
        //        using (CDPTrackEntities context = new CDPTrackEntities())
        //        {
        //            Assessment assessment = context.Assessment.Include("TermProperty").FirstOrDefault(x => x.AssessmentId == IdAssessment);

        //            ViewBag.ListOfTerms = (from term in context.Term select new { Text = term.Name, Value = term.TermId }).ToList();
        //            ViewBag.ListOfAssessmentCategories = (from category in context.AssessmentCategory select new { Text = category.Name, Value = category.AssessmentCategoryId }).ToList();

        //            return View(assessment);
        //        }
        //    }

        //    return RedirectToAction("SelfAssessment");
        //}

#if !DEBUG
        
#endif
        //[HttpPost]
        //public ActionResult EditAssessmentConfirmed(Assessment assessment)
        //{
        //    SetupCommonViewBagValues();
        //    if (ModelState.IsValid)
        //    {
        //        using (CDPTrackEntities context = new CDPTrackEntities())
        //        {
        //            context.Entry(assessment).State = EntityState.Modified;
        //            context.SaveChanges();
        //        }
        //    }

        //    return RedirectToAction("SelfAssessment");
        //}

#if !DEBUG
        
#endif
        //public ActionResult CreateAssessment(int resourceId, int category, int term)
        //{
        //    SetupCommonViewBagValues();
        //    using (CDPTrackEntities context = new CDPTrackEntities())
        //    {
        //        Assessment newAssessment = new Assessment();
        //        ViewBag.ListOfTerms = (from termOption in context.Term select new { Text = termOption.Name, Value = termOption.TermId }).ToList();
        //        ViewBag.ListOfAssessmentCategories = (from categoryOption in context.AssessmentCategory select new { Text = categoryOption.Name, Value = categoryOption.AssessmentCategoryId }).ToList();

        //        newAssessment.AssessmentCategory = category;
        //        newAssessment.Term = term;
        //        return View(newAssessment);
        //    }
        //}


#if !DEBUG
        
#endif
        //[HttpPost]
        //public ActionResult CreateAssessmentConfirmed(Assessment assessment)
        //{
        //    SetupCommonViewBagValues();
        //    using (CDPTrackEntities context = new CDPTrackEntities())
        //    {
        //        Resource resource;
        //        if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
        //        {
        //            TempData[ResourceController.IsRedirectBycode] = true;
        //            return RedirectToAction("SetupResourceData", "Resource");
        //        }

        //        if (assessment.ResourceId == resource.ResourceId)
        //        {
        //            assessment.DateCreated = DateTime.Now;
        //            context.Assessment.Add(assessment);
        //            context.SaveChanges();
        //        }
        //        return RedirectToAction("SelfAssessment");
        //    }
        //}
        #endregion

        #region Training Program

        public ActionResult TrainingProgram()
        {
            SetupCommonViewBagValues();

            try
            {
                Resource resource;
                ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource);

                CDPTrackEntities context = new CDPTrackEntities();
                var lstTrainingByEmployee = from a in context.TrainingProgram
                                            join b in context.TrainingProgramDetails on a.IdTrainingProgram equals b.IdTrainingProgram
                                            join c in context.TrainingProgramCategory on a.Category equals c.IdTrainingProgramCategory
                                            join d in context.Resources on b.ResourceId equals d.ResourceId
                                            join e in context.ProgressEnums on b.Status equals e.Id
                                            where b.ResourceId == resource.ResourceId
                                            select new { TrainingProgram = a, TrainingProgramDetail = b, TrainingProgramCategory = c, Resource = d, Progress = e };

                var lstTrainingProgramDetails = (from element in lstTrainingByEmployee
                                                 select new
                                                 {
                                                     IdTrainingProgramDetails = element.TrainingProgramDetail.IdTrainingProgramDetails,
                                                     IdTrainingProgram = element.TrainingProgramDetail.IdTrainingProgram,
                                                     TrainingProgram = element.TrainingProgram,
                                                     Status = element.TrainingProgramDetail.Status,
                                                     Progress = element.Progress,
                                                     ResourceId = element.Resource.ResourceId
                                                 }).ToList().Select(x => new TrainingProgramDetails
                                                 {
                                                     IdTrainingProgramDetails = x.IdTrainingProgramDetails,
                                                     IdTrainingProgram = x.IdTrainingProgram,
                                                     TrainingProgram = x.TrainingProgram,
                                                     Status = x.Status,
                                                     ProgressEnum = x.Progress,
                                                     ResourceId = x.ResourceId
                                                 }).OrderBy(x => x.TrainingProgram.TrainingProgramCategory.Name).ToList();

                var listOfDeleteTrainingsIds = context.TrainingProgram.Where(x => x.Enable == false).Select(x => x.IdTrainingProgram).ToList();

                List<TrainingProgramDetails> tpd = new List<TrainingProgramDetails>();

                foreach (var item in lstTrainingProgramDetails)
                {
                    if (listOfDeleteTrainingsIds.Contains(item.IdTrainingProgram))
                    {
                        if (item.Status != 0)
                        {
                            tpd.Add(item);
                        }
                    }
                    else
                    {
                        tpd.Add(item);
                    }
                }

                /**************************************************************************************/

                var listOfDeleteProgramsIds = context.GeneralTrainingProgram.Where(x => x.Enabled == false).Select(x => x.IdGeneralTrainingProgram).ToList();
                var generalTrainingProgramList = context.GeneralTrainingProgramDetails
                                                        .Where(x => x.ResourceId == resource.ResourceId)
                                                        .Select(x => x)
                                                        .OrderBy(x => x.GeneralTrainingProgram.TrainingProgramCategory.Name).ToList();

                List<GeneralTrainingProgramDetails> finalListGeneralPrograms = new List<GeneralTrainingProgramDetails>();

                foreach (var item in generalTrainingProgramList)
                {
                    if (listOfDeleteProgramsIds.Contains(item.IdGeneralTrainingProgram))
                    {
                        if (item.Status != 0)
                        {
                            finalListGeneralPrograms.Add(item);
                        }
                    }
                    else
                    {
                        finalListGeneralPrograms.Add(item);
                    }
                }

                /**************************************************************************************/

                List<TrainingProgramOnDemandDetails> tpodd = context.TrainingProgramOnDemandDetails.Include("TrainingProgramOnDemand").Where(m => m.ResourceId == resource.ResourceId).ToList();

                /**************************************************************************************/

                var models = new Tuple<IEnumerable<TrainingProgramDetails>, IEnumerable<GeneralTrainingProgramDetails>, IEnumerable<TrainingProgramOnDemandDetails>>
                    (tpd, finalListGeneralPrograms, tpodd);

                return View(models);

            }
            catch (Exception)
            {
                return View();
            }
        }

        public ActionResult EditTraining(int Id)
        {
            if (isHisTrainingProgram(Id))
            {
                TrainingProgramDetails tpd = new TrainingProgramDetails();

                try
                {
                    CDPTrackEntities context = new CDPTrackEntities();
                    tpd = context.TrainingProgramDetails.Find(Id);
                    ViewBag.ListOfProgress = new SelectList(GetProgresEnums(), "Id", "Label", tpd.ProgressEnum.Id);
                }
                catch (Exception)
                {
                    ViewBag.ListOfProgress = new SelectList(GetProgresEnums(), "Id", "Label");
                    tpd = null;
                }

                return View(tpd);
            }

            return RedirectToAction("TrainingProgram");
        }

        [HttpPost]
        public ActionResult EditTraining(TrainingProgramDetails tpd)
        {
            if (isHisTrainingProgram(tpd.IdTrainingProgramDetails))
            {
                try
                {
                    if (ModelState.IsValid)
                    {
                        using (CDPTrackEntities context = new CDPTrackEntities())
                        {
                            context.Entry(tpd).State = EntityState.Modified;
                            context.SaveChanges();
                        }
                        return RedirectToAction("TrainingProgram");
                    }
                }
                catch (Exception)
                { }

                return View();
            }

            return RedirectToAction("TrainingProgram");
        }

        public ActionResult EditGeneralTraining(int Id)
        {
            if (isHisGeneralTrainingProgram(Id))
            {
                GeneralTrainingProgramDetails tpd = new GeneralTrainingProgramDetails();

                try
                {
                    CDPTrackEntities context = new CDPTrackEntities();
                    tpd = context.GeneralTrainingProgramDetails.Find(Id);
                    ViewBag.ListOfProgress = new SelectList(GetProgresEnums(), "Id", "Label", tpd.ProgressEnum.Id);
                }
                catch (Exception)
                {
                    ViewBag.ListOfProgress = new SelectList(GetProgresEnums(), "Id", "Label");
                    tpd = null;
                }

                return View(tpd);
            }

            return RedirectToAction("TrainingProgram");
        }

        [HttpPost]
        public ActionResult EditGeneralTraining(GeneralTrainingProgramDetails tpd)
        {
            if (isHisGeneralTrainingProgram(tpd.IdGeneralTrainingProgramDetails))
            {
                try
                {
                    if (ModelState.IsValid)
                    {
                        using (CDPTrackEntities context = new CDPTrackEntities())
                        {
                            context.Entry(tpd).State = EntityState.Modified;
                            context.SaveChanges();
                        }
                        return RedirectToAction("TrainingProgram");
                    }
                }
                catch (Exception)
                { }
                return View();
            }
            return RedirectToAction("TrainingProgram");
        }

        public ActionResult EditTrainingProgramOnDemandStatus(int id)
        {
            TrainingProgramOnDemandDetails tpodd = new TrainingProgramOnDemandDetails();

            try
            {
                CDPTrackEntities context = new CDPTrackEntities();
                tpodd = context.TrainingProgramOnDemandDetails.Find(id);
                ViewBag.ListOfProgress = new SelectList(GetProgresEnums(), "Id", "Label", tpodd.Status);
            }
            catch (Exception)
            {
                ViewBag.ListOfProgress = new SelectList(GetProgresEnums(), "Id", "Label");
                tpodd = null;
            }

            return View(tpodd);
        }

        [HttpPost]
        public ActionResult EditTrainingProgramOnDemandStatus(TrainingProgramOnDemandDetails tpodd)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (CDPTrackEntities context = new CDPTrackEntities())
                    {
                        context.Entry(tpodd).State = EntityState.Modified;
                        context.SaveChanges();
                    }
                    return RedirectToAction("TrainingProgram");
                }
            }
            catch (Exception)
            { }
            return View();
        }

        private bool isHisGeneralTrainingProgram(int idGeneralTrainingProgram)
        {
            Resource resource;

            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
                return false;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<GeneralTrainingProgramDetails> assessmentList = context.GeneralTrainingProgramDetails.Where(x => x.ResourceId == resource.ResourceId && x.IdGeneralTrainingProgramDetails == idGeneralTrainingProgram).ToList();
                return assessmentList.Count > 0;
            }
        }

        private bool isHisTrainingProgram(int idTrainingProgram)
        {
            Resource resource;

            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
                return false;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<TrainingProgramDetails> assessmentList = context.TrainingProgramDetails.Where(x => x.ResourceId == resource.ResourceId && x.IdTrainingProgramDetails == idTrainingProgram).ToList();
                return assessmentList.Count > 0;
            }
        }
        #endregion


        #region Training Program On Demand

        public ActionResult TrainingProgramOnDemand()
        {
            SetupCommonViewBagValues();

            Resource resource;
            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
            {
                TempData[ResourceController.IsRedirectBycode] = true;
                return RedirectToAction("SetupResourceData", "Resource");
            }

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<TrainingProgramOnDemand> lstTrainings = new List<TrainingProgramOnDemand>();

                var duplicates = from TrainingEmployee in context.TrainingProgramOnDemandDetails
                                 from TrainingOnDemand in context.TrainingProgramOnDemand
                                 where (TrainingEmployee.IdTrainingProgramOnDemand == TrainingOnDemand.IdTrainingProgramOnDemand &&
                                        TrainingEmployee.ResourceId == resource.ResourceId)
                                 select TrainingOnDemand;

                lstTrainings = context.TrainingProgramOnDemand.Where(x => x.Enable == true).Except(duplicates).ToList();
                return View(lstTrainings);
            }
        }

        [HttpPost]
        public ActionResult TrainingProgramOnDemand(TrainingProgramOnDemandDetails tpodd, int id)
        {
            SetupCommonViewBagValues();

            Resource resource;
            if (!ResourceDataAccessor.TryGetResourceByUserName(User.Identity.Name, out resource))
            {
                TempData[ResourceController.IsRedirectBycode] = true;
                return RedirectToAction("SetupResourceData", "Resource");
            }

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                if (ModelState.IsValid)
                {
                    tpodd.IdTrainingProgramOnDemand = id;
                    tpodd.Status = 0;
                    tpodd.ResourceId = resource.ResourceId;
                    context.TrainingProgramOnDemandDetails.Add(tpodd);
                    context.SaveChanges();

                    return RedirectToAction("TrainingProgramOnDemand");
                }
                else
                {
                    ModelState.AddModelError("Error", "There is something wrong.");
                }
            }

            return View();
        }

        #endregion

        #endregion

        /***********************************************************  Region for Action Results of "CDP Guidelines" ************************/
        #region CDP Guidelines

        #region Career Path
        public ActionResult CareerPath()
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = 0;

            return View();
        }

        [HttpPost]
        public ActionResult CareerPath(Area area, int IdArea)
        {
            SetupCommonViewBagValues();

            List<Area> areas = new List<Area>();

            CDPTrackEntities context = new CDPTrackEntities();
            areas = context.Area.ToList();

            var areaItem = areas.Find(x => x.AreaId == IdArea);

            ViewBag.AreaId = areaItem.AreaId;
            if (areaItem.ImageCareerPath != null)
            {
                ViewBag.FileName = areaItem.ImageCareerPath;
            }
            else
            {
                ViewBag.FileName = "default.jpg";
            }

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", IdArea);

            //string DirPath = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)));
            //string FilePath = DirPath + @"\CDPTrackerSite\Content\images\CareerPath\" + areaItem.ImageCareerPath;
            //if (System.IO.File.Exists(FilePath))
            //{                
            //}

            return View(area);
        }
        #endregion

        #region Job Description
        public ActionResult JobDescription()
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = 0;

            return View();
        }

        [HttpPost]
        public ActionResult JobDescription(List<Position> position, int Area)
        {
            SetupCommonViewBagValues();

            try
            {
                ViewBag.AreaId = Area;
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", Area);

                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    var positionsByArea = context.Position.Include("Area")
                                                          .Where(x => x.AreaId == Area && x.PositionName != "UNKNOWN")
                                                          .OrderBy(x => x.PositionName).ToList();

                    ViewBag.Area = positionsByArea.FirstOrDefault().Area.Name.ToString();
                    position = positionsByArea;
                }
            }
            catch (Exception)
            {
                position = null;
            }

            return View(position);
        }
        #endregion

        #region Skill Compass

        public ActionResult SkillCompass()
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = 0;

            return View();
        }

        [HttpPost]
        public ActionResult SkillCompass(Area area, int IdArea)
        {
            SetupCommonViewBagValues();

            List<Area> areas = new List<Area>();
            List<SkillCompassGlossary> glossary = new List<SkillCompassGlossary>();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                areas = context.Area.ToList();
                glossary = context.SkillCompassGlossary.Where(x => x.AreaId == IdArea).OrderBy(x => x.Name).ToList();
            }

            var areaItem = areas.Find(x => x.AreaId == IdArea);

            ViewBag.AreaId = areaItem.AreaId;
            if (areaItem.ImageSkillCompass != null)
            {
                ViewBag.FileName = areaItem.ImageSkillCompass;
            }
            else
            {
                ViewBag.FileName = "default.jpg";
            }

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", IdArea);
            ViewBag.glossary = glossary;
            return View(area);
        }

        public JsonResult JsonGetGlossary(string id)
        {
            List<SelectListItem> glossary = new List<SelectListItem>();

            int AreaId = 0;
            int.TryParse(id, out AreaId);

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                if (AreaId != 0)
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    var glossaryByArea = context.SkillCompassGlossary.Where(x => x.AreaId == AreaId).ToList();

                    foreach (SkillCompassGlossary item in glossaryByArea)
                    {
                        glossary.Add(new SelectListItem { Value = item.SkillCompassGlossaryId.ToString(), Text = item.Name });
                    }

                    return Json(new SelectList(glossary, "Value", "Text"));
                }
                else
                {
                    return Json(new SelectList(glossary, "Value", "Text"));
                }
            }
        }

        public JsonResult JsonGetSkillDescription(string SkillCompassId)
        {
            int SkillId = 0;
            int.TryParse(SkillCompassId, out SkillId);

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                SkillCompassGlossary skillFound = new SkillCompassGlossary();
                if (SkillId != 0)
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    skillFound = context.SkillCompassGlossary.Where(x => x.SkillCompassGlossaryId == SkillId).FirstOrDefault();
                    return Json(skillFound);
                }
                else
                {
                    return Json(skillFound);
                }
            }
        }


        #endregion

        #region Suggestions
        public ActionResult Suggestions()
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = 0;
            ViewBag.PositionId = 0;

            if (Session["Position"] != null)
            {
                int AreaId = 0;
                int.TryParse(Session["Area"].ToString(), out AreaId);

                int PositionId = 0;
                int.TryParse(Session["Position"].ToString(), out PositionId);

                var lstSuggestions = ObtainSuggestionTable(PositionId);

                ViewBag.AreaId = AreaId;
                ViewBag.PositionId = PositionId;

                Session["Area"] = null;
                Session["Position"] = null;

                return View(lstSuggestions);
            }

            Session["Area"] = null;
            Session["Position"] = null;

            return View();
        }

        [HttpPost]
        public ActionResult Suggestions(Suggestions suggestions, int Area, int Position)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    var lstSuggestions = context.Suggestions.Include("Position")
                                                            .Include("Technologies")
                                                            .Include("Level")
                                                            .Where(m => m.PositionId == Position)
                                                            .OrderBy(m => m.Technologies.Name)
                                                            .ThenBy(m => m.Level.Name)
                                                            .ToList();

                    ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                    ViewBag.AreaId = Area;
                    ViewBag.PositionId = Position;

                    return View(lstSuggestions);
                }
            }
            catch (Exception)
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                return View();
            }
        }

        public JsonResult JsonGetPosition(string id)
        {
            List<SelectListItem> position = new List<SelectListItem>();

            int AreaId = 0;
            int.TryParse(id, out AreaId);

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                if (AreaId != 0)
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    var positionsByArea = context.Position.Include("Area")
                                                          .Where(x => x.AreaId == AreaId && x.PositionName != "UNKNOWN")
                                                          .ToList();

                    foreach (Position item in positionsByArea)
                    {
                        position.Add(new SelectListItem { Value = item.PositionId.ToString(), Text = item.PositionName });
                    }

                    return Json(new SelectList(position, "Value", "Text"));
                }
                else
                {
                    return Json(new SelectList(position, "Value", "Text"));
                }
            }
        }
        #endregion

        #endregion

        /**********************************************************  Region for Action Results of "Employee Goals"**************************/
        #region Employee Goals

        #region Pending Verifications
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult PendingVerifications()
        {
            List<EmployeeActiveDirectoryManager.UserData> userData = ResourceDataAccessor.GetUserData();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                var resourcesPendingVerification =
                    context.Resources.Where(r => r.GoalTrackings.Any(g => g.Progress == (int)ProgressEnumeration.Completed && !g.VerifiedByManager))
                    .Select(r => new
                    {
                        r.DomainName,
                        PendingGoalCount = r.GoalTrackings.Count(g => g.Progress == (int)ProgressEnumeration.Completed && !g.VerifiedByManager)
                    }).ToList();

                var resourcesPendingVerificationAddedManager =
                    resourcesPendingVerification
                        .Select(r => new
                        {
                            r.DomainName,
                            r.PendingGoalCount,
                            ManagerName = GetManager(r.DomainName, userData)
                        }).ToList();

                //remove employees without a manager.
                resourcesPendingVerificationAddedManager = resourcesPendingVerificationAddedManager.Where(x => x.ManagerName != string.Empty).ToList();

                var managersPendingGoalVerification = from a in resourcesPendingVerificationAddedManager
                                                      group a by a.ManagerName into g
                                                      select new { ManagerName = g.Key, GoalsPendingVerificationCount = g.Sum(m => m.PendingGoalCount), DirectReport = g.ToList() };


                SetupCommonViewBagValues();
                ViewBag.Name = User.Identity.Name.StripDomain();
                return View(managersPendingGoalVerification);
            }
        }
        #endregion

        #region Employee Goals Tracking
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult EmployeeGoals(Resource resource)
        {
            // ReSharper disable RedundantAssignment
            string managerName = User.Identity.Name;
            // ReSharper restore RedundantAssignment

#if DEBUG
            managerName = "daniela lugo";
#endif

            Resource manager;
            if (!ResourceDataAccessor.TryGetResourceByUserName(managerName, out manager))
            {
                return View();
            }

            List<Resource> managerResources;
            if (!ResourceDataAccessor.TryGetResourcesFromManager(managerName, out managerResources))
            {
                return View();
            }

            manager.Employees =
                managerResources.Where(r => r.Employee != null).Select(r => r.Employee).OrderBy(r => r.Resource.Name).
                    ToList();

            SetupCommonViewBagValues();
            return View(manager);
        }
        #endregion

        #region Goal Verification
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult ManagerVerification()
        {
            // ReSharper disable RedundantAssignment
            string managerName = User.Identity.Name;
            // ReSharper restore RedundantAssignment

#if DEBUG
            managerName = "daniela lugo";
#endif

            Resource manager;
            if (!ResourceDataAccessor.TryGetResourceByUserName(managerName, out manager))
            {
                return View();
            }

            List<Resource> managerResources;
            if (!ResourceDataAccessor.TryGetVerifiableResourcesFromManager(managerName, out managerResources))
            {
                return View();
            }

            manager.Employees =
                managerResources.Where(r => r.Employee != null).Select(r => r.Employee).OrderBy(r => r.Resource.Name).
                    ToList();

            int goalCount = GetGoalsCountFromManagerResources(managerResources);

            SetupCommonViewBagValues(goalCount);
            return View(manager);
        }

        [HttpPost]
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult ManagerVerification(Resource resource)
        {
            List<Resource> originalResources;
            // ReSharper disable RedundantAssignment
            string managerName = User.Identity.Name;
            // ReSharper restore RedundantAssignment

#if DEBUG
            managerName = "daniela lugo";
#endif
            if (ResourceDataAccessor.TryGetVerifiableResourcesFromManager(managerName, out originalResources))
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    bool isUpdated = false;
                    foreach (Employee updatedEmployee in resource.Employees)
                    {
                        var updatedResource = updatedEmployee.Resource;
                        if (updatedResource == null) continue;

                        var resourceId = updatedResource.ResourceId;
                        var originalGoals = context.GoalTrackings.Where(g => g.ResourceId == resourceId);
                        if (!originalGoals.Any()) continue;

                        foreach (var updatedGoal in updatedResource.GoalTrackings)
                        {
                            var goalId = updatedGoal.GoalId;
                            var originalGoal = originalGoals.FirstOrDefault(g => g.GoalId == goalId);
                            if (originalGoal == null) continue;

                            if (updatedGoal.VerifiedByManager != originalGoal.VerifiedByManager)
                            {
                                originalGoal.VerifiedByManager = updatedGoal.VerifiedByManager;
                                originalGoal.LastUpdate = DateTime.Now;
                                context.Entry(originalGoal).State = EntityState.Modified;

                                isUpdated = true;
                            }
                        }
                    }
                    if (isUpdated)
                    {
                        context.SaveChanges();
                    }
                }
            }
            return RedirectToAction("Index");
        }
        #endregion

        #endregion

        /*********************************************************** Region for Action Results of "Reports" Area ***************************/
        #region Reports

        #region Pending Verifications

        [HttpPost]
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult ForceGoalVerification(bool IsManager, bool isTalentManagement, string name)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                try
                {
                    if (isTalentManagement)
                    {
                        var goalsPendingVerification =
                            context.GoalTrackings.Where(g => g.Progress == (int)ProgressEnumeration.Completed && !g.VerifiedByManager).ToList();

                        foreach (var goalTracking in goalsPendingVerification)
                        {
                            goalTracking.VerifiedByManager = true;
                            goalTracking.FinishDate = goalTracking.FinishDate ?? DateTime.Now;
                        }
                        context.SaveChanges();

                    }
                    else
                    {
                        EmployeeActiveDirectoryManager Ad = getActiveDirectoryInstance();

                        Resource employee = context.Resources.Where(x => x.DomainName == name).FirstOrDefault();
                        List<string> resources = Ad.GetManagerResourcesDomainNames(employee.DomainName);

                        foreach (var resource in resources)
                        {
                            Resource employeeObject = context.Resources.Where(x => x.DomainName == resource).FirstOrDefault();
                            var goalsPendingVerification =
                                context.GoalTrackings.Where(g => g.Progress == (int)ProgressEnumeration.Completed && !g.VerifiedByManager && g.ResourceId == employeeObject.ResourceId).ToList();

                            foreach (var goalTracking in goalsPendingVerification)
                            {
                                goalTracking.VerifiedByManager = true;
                                goalTracking.FinishDate = goalTracking.FinishDate ?? DateTime.Now;
                            }
                        }
                        context.SaveChanges();

                    }
                }

                catch (DbEntityValidationException ex) { }
                catch (Exception) { }
            }
            return RedirectToAction("Index");
        }
        #endregion

        #region ProgressReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult ProgressReport()
        {
            SetupProgressReportData();

            return View();
        }
        #endregion

        #region MonthlyReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement, Role.Manager)]
#endif
        public ActionResult MonthlyReport()
        {
            SetupProgressReportData();

            return View();
        }
        #endregion

        #region ProgressReportWithArea

#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement)]
#endif
        public ActionResult ProgressReportWithArea()
        {
            SetupProgressReportData();

            return View();
        }
        #endregion

        #region NoObjectivesReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement)]
#endif
        public ActionResult NoObjectivesReport()
        {
            SetupProgressReportData();

            ListOfYears();
            ViewBag.Year = GetCurrentYear();
            ViewBag.ListOfQuarters = new SelectList(GetQuarter(), "Value", "Text", GetActualQuarter());

            return View();
        }
        #endregion

        #region UnassignObjectiveReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement)]
#endif
        public ActionResult UnassignObjectiveReport()
        {
            SetupProgressReportData();

            return View();
        }
        #endregion

        #region ProgressByProjectReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement)]
#endif
        public ActionResult ProgressByProjectReport()
        {
            SetupProgressReportData();

            Reporting.ProgressByProjectReport reportObject = new Reporting.ProgressByProjectReport();
            reportObject.getEmployeesGoalsByProject();

            List<IEnumerable> combosData = new List<IEnumerable>();
            combosData.Add(Reporting.ProgressByProjectReport.areas);
            combosData.Add(Reporting.ProgressByProjectReport.projects);

            return View(combosData);
        }
        #endregion

        #region SelfAssessmentReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement)]
#endif
        public ActionResult SelfAssessmentReport()
        {
            SetupCommonViewBagValues();
            return View();
        }
        #endregion

        #region commonReportMethods
        private void SetupProgressReportData()
        {
            SetupCommonViewBagValues();

            int minYear = -1;
            int maxYear = -1;
            int minMonth = -1;
            int maxMonth = -1;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                DateTime? maxDate = context.GoalTrackings.Where(g => g.VerifiedByManager).Max(g => g.LastUpdate);
                DateTime? minDate = context.GoalTrackings.Where(g => g.VerifiedByManager).Min(g => g.LastUpdate);
                if (maxDate.HasValue)
                {
                    maxYear = maxDate.Value.Year;
                    maxMonth = maxDate.Value.Month;
                }
                if (minDate.HasValue)
                {
                    minYear = minDate.Value.Year;
                    minMonth = minDate.Value.Month;
                }
            }
            ViewBag.MinYear = minYear;
            ViewBag.MinMonth = minMonth;
            ViewBag.MaxYear = maxYear;
            ViewBag.MaxMonth = maxMonth;
        }
        #endregion

        #region TrainingProgramReport
#if !DEBUG
        [RoleAuthorization(Role.Executive, Role.TalentManagement)]
#endif
        public ActionResult TrainingProgramReport()
        {
            SetupCommonViewBagValues();
            return View();
        }
        #endregion
        #endregion

        /************************************************************ Region for Action Results of "Admin Catalogs" Area ********************/
        #region Admin Catalogs

        #region Job Description Admin
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult JobDescriptionAdmin()
        {
            SetupCommonViewBagValues();

            //string id = Request.QueryString["id"] ?? "0";
            int id = 0;
            int.TryParse(Request.QueryString["id"], out id);

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = id;

            if (id != 0)
            {
                ViewBag.AreaId = id;
                return View(ObtainPositionTable(id));
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult JobDescriptionAdmin(List<Position> position, int Area)
        {
            SetupCommonViewBagValues();

            try
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", Area);
                position = ObtainPositionTable(Area);

                ViewBag.AreaId = Area;
            }
            catch (Exception)
            {
                position = null;
            }

            return View(position);
        }

        public List<Position> ObtainPositionTable(int AreaId)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                context.Configuration.LazyLoadingEnabled = false;
                var positionsByArea = context.Position.Include("Area").Where(x => x.AreaId == AreaId && x.PositionName != "UNKNOWN")
                    .OrderBy(x => x.PositionName).ToList();
                ViewBag.Area = positionsByArea.FirstOrDefault().Area.Name.ToString();
                return positionsByArea;
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditLink(int id)
        {
            SetupCommonViewBagValues();

            Position position;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                var queryPosition = context.Position.Include("Area").Where(x => x.PositionId == id);

                position = new Position();
                position.Area = new Area();

                position.AreaId = queryPosition.FirstOrDefault().AreaId;
                position.Area.Name = queryPosition.FirstOrDefault().Area.Name;
                position.PositionId = queryPosition.FirstOrDefault().PositionId;
                position.PositionName = queryPosition.FirstOrDefault().PositionName;
                position.Description = queryPosition.FirstOrDefault().Description;

                return View(position);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditLink(Position position)
        {
            SetupCommonViewBagValues();
            ViewBag.error = "";

            try
            {
                if (ModelState.IsValid)
                {
                    bool verifyUrl = UrlIsValid(position.Description);
                    if (verifyUrl)
                    {
                        using (CDPTrackEntities context = new CDPTrackEntities())
                        {
                            context.Entry(position).State = EntityState.Modified;
                            context.SaveChanges();
                        }

                        return RedirectToAction("JobDescriptionAdmin", new { id = position.AreaId });
                    }
                    else
                    {
                        ViewBag.error = "The URL is invalid.";
                    }
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Diagnostics.Trace.TraceInformation("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
            catch (Exception)
            {
                ViewBag.error = "Value cannot be null.";
            }

            return View(position);
        }

        public static bool UrlIsValid(string url)
        {
            bool br = false;
            try
            {
                Uri myUri = new Uri(url);
                string host = myUri.Host;

                IPHostEntry ipHost = Dns.GetHostEntry(host);
                br = true;
            }
            catch (SocketException se)
            {
                if (se.ErrorCode == 11004)
                { br = true; }
                else
                { br = false; }
            }
            return br;
        }
        #endregion

        #region Technology
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult Technology()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<Technologies> lstTechnologies = context.Technologies.OrderBy(m => m.Name).ToList();

                return View(lstTechnologies);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateTechnology()
        {
            SetupCommonViewBagValues();

            ViewBag.error = "";

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateTechnology(Technologies technologies)
        {
            SetupCommonViewBagValues();

            //var errors = ModelState.Values.SelectMany(v => v.Errors);

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Technologies.Add(technologies);
                    context.SaveChanges();

                    return RedirectToAction("Technology");
                }
            }
            catch (Exception)
            {
                ViewBag.error = "The Technology field is required";
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditTechnology(int id)
        {
            SetupCommonViewBagValues();
            Technologies technology = new Technologies();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var query = context.Technologies.Where(x => x.TechnologyId == id);

                    technology.TechnologyId = query.FirstOrDefault().TechnologyId;
                    technology.Name = query.FirstOrDefault().Name;

                    ViewBag.error = "";
                    return View(technology);
                }
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditTechnology(Technologies technologies)
        {
            SetupCommonViewBagValues();

            try
            {
                if (ModelState.IsValid)
                {
                    using (CDPTrackEntities context = new CDPTrackEntities())
                    {
                        context.Entry(technologies).State = EntityState.Modified;
                        context.SaveChanges();
                    }

                    return RedirectToAction("Technology");
                }
                else
                {
                    var message = string.Join(" | ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    ViewBag.error = message.ToString();
                    return View();
                }
            }
            catch (Exception)
            {
                ViewBag.error = "The Technology field is required";
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteTechnology(int id)
        {
            SetupCommonViewBagValues();
            Technologies technologies = new Technologies();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var technology = context.Technologies.Where(m => m.TechnologyId == id);
                    technologies.TechnologyId = technology.FirstOrDefault().TechnologyId;
                    technologies.Name = technology.FirstOrDefault().Name;

                    ViewBag.error = "";
                }
            }
            catch (Exception e)
            {
                technologies = null;
                ViewBag.error = "Error Message: " + e.Message;
            }

            return View(technologies);
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteTechnology(Technologies technologies)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var technology = context.Technologies.Find(technologies.TechnologyId);
                    technologies.Name = technology.Name;
                    context.Technologies.Remove(technology);
                    context.SaveChanges();

                    return RedirectToAction("Technology");
                }
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View(technologies);
            }
        }
        #endregion

        #region Suggestion Admin
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult SuggestionsAdmin()
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = 0;
            ViewBag.PositionId = 0;

            if (Session["Position"] != null)
            {
                int AreaId = 0;
                int.TryParse(Session["Area"].ToString(), out AreaId);

                int PositionId = 0;
                int.TryParse(Session["Position"].ToString(), out PositionId);

                var lstSuggestions = ObtainSuggestionTable(PositionId);

                ViewBag.AreaId = AreaId;
                ViewBag.PositionId = PositionId;

                Session["Area"] = null;
                Session["Position"] = null;
                Session["Technology"] = null;
                Session["Level"] = null;

                return View(lstSuggestions);
            }

            Session["Area"] = null;
            Session["Position"] = null;
            Session["Technology"] = null;
            Session["Level"] = null;

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult SuggestionsAdmin(Suggestions suggestions, int Area, int Position)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    var lstSuggestions = context.Suggestions.Include("Position").Include("Technologies").Include("Level")
                        .Where(m => m.PositionId == Position).OrderBy(m => m.Technologies.Name).ThenBy(m => m.Level.Name)
                        .ToList();

                    ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                    ViewBag.AreaId = Area;
                    ViewBag.PositionId = Position;

                    return View(lstSuggestions);
                }
            }
            catch (Exception)
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateSuggestion()
        {
            SetupCommonViewBagValues();

            try
            {
                string ida = Request.QueryString["ida"];
                string idp = Request.QueryString["idp"];

                ViewBag.AreaId = ida;
                ViewBag.PositionId = idp;
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name");
                ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name");
            }
            catch (Exception)
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name");
                ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name");
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateSuggestion(Suggestions suggestion, int Area, int Position, int Technology, int Level)
        {
            SetupCommonViewBagValues();

            try
            {
                suggestion.PositionId = Position;
                suggestion.TechnologyId = Technology;
                suggestion.LevelId = Level;

                ViewBag.AreaId = Area;
                ViewBag.PositionId = Position;
                ViewBag.error = "";

                bool verifyUrl = UrlIsValid(suggestion.Source);
                if (verifyUrl)
                {
                    ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                    ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name");
                    ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name");

                    using (CDPTrackEntities context = new CDPTrackEntities())
                    {
                        context.Suggestions.Add(suggestion);
                        context.SaveChanges();
                    }

                    return RedirectToAction("SuggestionsAdmin");
                }
                else
                {
                    ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", Area);
                    ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name", suggestion.TechnologyId);
                    ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name", suggestion.LevelId);
                    ViewBag.error = "The URL is invalid";
                }
            }
            catch (Exception e)
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", Area);
                ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name", suggestion.TechnologyId);
                ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name", suggestion.LevelId);
                ViewBag.error = e.Message;
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditSuggestion(int id)
        {
            SetupCommonViewBagValues();
            Suggestions suggestion = new Suggestions();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var querySuggestion = context.Suggestions.Where(x => x.SuggestionId == id);

                    suggestion.SuggestionId = querySuggestion.FirstOrDefault().SuggestionId;
                    suggestion.PositionId = querySuggestion.FirstOrDefault().PositionId;
                    suggestion.TechnologyId = querySuggestion.FirstOrDefault().TechnologyId;
                    suggestion.LevelId = querySuggestion.FirstOrDefault().LevelId;
                    suggestion.Topic = querySuggestion.FirstOrDefault().Topic;
                    suggestion.Source = querySuggestion.FirstOrDefault().Source;

                    var queryArea = context.Position.Where(x => x.PositionId == querySuggestion.FirstOrDefault().PositionId);

                    ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", queryArea.FirstOrDefault().AreaId);
                    ViewBag.ListOfPositions = new SelectList(GetPosition(), "PositionId", "PositionName", querySuggestion.FirstOrDefault().PositionId);
                    ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name", querySuggestion.FirstOrDefault().TechnologyId);
                    ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name", querySuggestion.FirstOrDefault().LevelId);

                    Session["Area"] = queryArea.FirstOrDefault().AreaId;
                    Session["Position"] = querySuggestion.FirstOrDefault().PositionId;
                    Session["Technology"] = querySuggestion.FirstOrDefault().TechnologyId;
                    Session["Level"] = querySuggestion.FirstOrDefault().LevelId;

                    ViewBag.AreaId = 0;
                    ViewBag.PositionId = 0;
                    ViewBag.error = "";

                    return View(suggestion);
                }
            }
            catch (Exception)
            {
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditSuggestion(Suggestions suggestion, int Area, int Position, int Technology, int Level)
        {
            SetupCommonViewBagValues();
            ViewBag.error = "";

            try
            {
                bool verifyUrl = UrlIsValid(suggestion.Source);
                if (verifyUrl)
                {
                    using (CDPTrackEntities context = new CDPTrackEntities())
                    {
                        suggestion.PositionId = Position;
                        suggestion.TechnologyId = Technology;
                        suggestion.LevelId = Level;
                        context.Entry(suggestion).State = EntityState.Modified;
                        context.SaveChanges();
                    }

                    return RedirectToAction("SuggestionsAdmin");
                }
                else
                {
                    ViewBag.error = "The URL is invalid";
                }

                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.AreaId = Area;
                ViewBag.PositionId = Position;

                ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name", Technology);
                ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name", Level);
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Diagnostics.Trace.TraceInformation("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }

                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.AreaId = int.Parse(Session["Area"].ToString());
                ViewBag.PositionId = int.Parse(Session["Position"].ToString());

                ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name", int.Parse(Session["Technology"].ToString()));
                ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name", int.Parse(Session["Level"].ToString()));
            }
            catch (Exception e)
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.AreaId = int.Parse(Session["Area"].ToString());
                ViewBag.PositionId = int.Parse(Session["Position"].ToString());

                ViewBag.ListOfTechnologies = new SelectList(GetTechnology(), "TechnologyId", "Name", int.Parse(Session["Technology"].ToString()));
                ViewBag.ListOfLevels = new SelectList(GetLevel(), "LevelId", "Name", int.Parse(Session["Level"].ToString()));
                ViewBag.error = e.Message;
            }

            return View(suggestion);
        }

        public List<Suggestions> ObtainSuggestionTable(int PositionId)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                context.Configuration.LazyLoadingEnabled = false;
                var lstSuggestions = context.Suggestions.Include("Position").Include("Technologies").Include("Level")
                    .Where(m => m.PositionId == PositionId).OrderBy(m => m.Technologies.Name).ThenBy(m => m.Level.Name)
                    .ToList();

                return lstSuggestions;
            }
        }


#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteSuggestion(int id)
        {
            SetupCommonViewBagValues();
            Suggestions suggestion = new Suggestions();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var queryTopic = context.Suggestions.Include("Position").Include("Technologies").Include("Level").Where(m => m.SuggestionId == id);

                    suggestion.Position = new Position();
                    suggestion.Position.Area = new Area();
                    suggestion.Technologies = new Technologies();
                    suggestion.Level = new Level();

                    suggestion.SuggestionId = queryTopic.FirstOrDefault().SuggestionId;
                    suggestion.Position.Area.Name = queryTopic.FirstOrDefault().Position.Area.Name;
                    suggestion.Position.PositionName = queryTopic.FirstOrDefault().Position.PositionName;
                    suggestion.Technologies.Name = queryTopic.FirstOrDefault().Technologies.Name;
                    suggestion.Level.Name = queryTopic.FirstOrDefault().Level.Name;
                    suggestion.Topic = queryTopic.FirstOrDefault().Topic;
                    suggestion.Source = queryTopic.FirstOrDefault().Source;

                    Session["Area"] = queryTopic.FirstOrDefault().Position.AreaId;
                    Session["Position"] = queryTopic.FirstOrDefault().PositionId;
                    ViewBag.error = "";
                }
            }
            catch (Exception e)
            {
                suggestion = null;
                ViewBag.error = "Error Message: " + e.Message;
            }

            return View(suggestion);
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteSuggestion(Suggestions suggestion)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var querySuggestion = context.Suggestions.Find(suggestion.SuggestionId);
                    context.Suggestions.Remove(querySuggestion);
                    context.SaveChanges();

                    return RedirectToAction("SuggestionsAdmin");
                }
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View();
            }
        }
        #endregion

        #region Level
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult Level()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<Level> lstLevel = context.Level.OrderBy(m => m.Name).ToList();

                return View(lstLevel);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateLevel()
        {
            SetupCommonViewBagValues();

            ViewBag.error = "";

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateLevel(Level level)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Level.Add(level);
                    context.SaveChanges();

                    return RedirectToAction("Level");
                }
            }
            catch (Exception)
            {
                ViewBag.error = "The Level field is required";
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditLevel(int id)
        {
            SetupCommonViewBagValues();
            Level level = new Level();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var query = context.Level.Where(x => x.LevelId == id);

                    level.LevelId = query.FirstOrDefault().LevelId;
                    level.Name = query.FirstOrDefault().Name;
                }

                ViewBag.error = "";
                return View(level);
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditLevel(Level level)
        {
            SetupCommonViewBagValues();

            try
            {
                if (ModelState.IsValid)
                {
                    using (CDPTrackEntities context = new CDPTrackEntities())
                    {
                        context.Entry(level).State = EntityState.Modified;
                        context.SaveChanges();
                    }

                    return RedirectToAction("Level");
                }
                else
                {
                    var message = string.Join(" | ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    ViewBag.error = message.ToString();
                    return View();
                }
            }
            catch (Exception)
            {
                ViewBag.error = "The Level field is required";
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteLevel(int id)
        {
            SetupCommonViewBagValues();
            Level level = new Level();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var queryLevel = context.Level.Where(m => m.LevelId == id);
                    level.LevelId = queryLevel.FirstOrDefault().LevelId;
                    level.Name = queryLevel.FirstOrDefault().Name;

                    ViewBag.error = "";
                }
            }
            catch (Exception e)
            {
                level = null;
                ViewBag.error = "Error Message: " + e.Message;
            }

            return View(level);
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteLevel(Level level)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var queryLevel = context.Level.Find(level.LevelId);
                    level.Name = queryLevel.Name;
                    context.Level.Remove(queryLevel);
                    context.SaveChanges();

                    return RedirectToAction("Level");
                }
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View(level);
            }
        }
        #endregion

        #region Training Program Category
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult TrainingProgramCategory()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<TrainingProgramCategory> lstTraining = context.TrainingProgramCategory.OrderBy(m => m.Name).ToList();

                return View(lstTraining);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateTrainingProgramCategory()
        {
            SetupCommonViewBagValues();

            ViewBag.error = "";

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateTrainingProgramCategory(TrainingProgramCategory training)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.TrainingProgramCategory.Add(training);
                    context.SaveChanges();

                    return RedirectToAction("TrainingProgramCategory");
                }
            }
            catch (Exception)
            {
                ViewBag.error = "The Training Program field is required";
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditTrainingProgramCategory(int id)
        {
            SetupCommonViewBagValues();
            TrainingProgramCategory training = new TrainingProgramCategory();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var query = context.TrainingProgramCategory.Where(x => x.IdTrainingProgramCategory == id);

                    training.IdTrainingProgramCategory = query.FirstOrDefault().IdTrainingProgramCategory;
                    training.Name = query.FirstOrDefault().Name;

                    ViewBag.error = "";
                    return View(training);
                }
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditTrainingProgramCategory(TrainingProgramCategory training)
        {
            SetupCommonViewBagValues();

            try
            {
                if (ModelState.IsValid)
                {
                    using (CDPTrackEntities context = new CDPTrackEntities())
                    {
                        context.Entry(training).State = EntityState.Modified;
                        context.SaveChanges();
                    }

                    return RedirectToAction("TrainingProgramCategory");
                }
                else
                {
                    var message = string.Join(" | ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    ViewBag.error = message.ToString();
                    return View();
                }
            }
            catch (Exception)
            {
                ViewBag.error = "The Training Program field is required";
                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteTrainingProgramCategory(int id)
        {
            SetupCommonViewBagValues();
            TrainingProgramCategory training = new TrainingProgramCategory();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var queryTraining = context.TrainingProgramCategory.Where(m => m.IdTrainingProgramCategory == id);
                    training.IdTrainingProgramCategory = queryTraining.FirstOrDefault().IdTrainingProgramCategory;
                    training.Name = queryTraining.FirstOrDefault().Name;

                    ViewBag.error = "";
                }
            }
            catch (Exception e)
            {
                training = null;
                ViewBag.error = "Error Message: " + e.Message;
            }

            return View(training);
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteTrainingProgramCategory(TrainingProgramCategory training)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    var queryTraining = context.TrainingProgramCategory.Find(training.IdTrainingProgramCategory);
                    training.Name = queryTraining.Name;
                    context.TrainingProgramCategory.Remove(queryTraining);
                    context.SaveChanges();

                    return RedirectToAction("TrainingProgramCategory");
                }
            }
            catch (Exception e)
            {
                ViewBag.error = "Error Message: " + e.Message;
                return View(training);
            }
        }
        #endregion

        #region Training Program Admin

        public List<TrainingProgram> ObtainTrainingTable(int PositionId)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                ViewBag.PositionSelected = context.Position.Find(PositionId).PositionName;
                List<TrainingProgram> listTrainingPrograms = context.TrainingProgram.Include("TrainingProgramCategory")
                                                                                    .Where(x => x.Position == PositionId && x.Enable == true)
                                                                                    .OrderBy(m => m.TrainingProgramCategory.Name).ToList();

                return listTrainingPrograms;
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult TrainingProgramAdmin()
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.PositionId = 0;
            ViewBag.AreaId = 0;

            if (Session["PositionId"] != null)
            {
                int AreaId = 0;
                int.TryParse(Session["AreaId"].ToString(), out AreaId);

                int PositionId = 0;
                int.TryParse(Session["PositionId"].ToString(), out PositionId);

                var lstTraining = ObtainTrainingTable(PositionId);

                ViewBag.AreaId = AreaId;
                ViewBag.PositionId = PositionId;

                Session["AreaId"] = null;
                Session["PositionId"] = null;

                return View(lstTraining);
            }

            Session["AreaId"] = null;
            Session["PositionId"] = null;

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult TrainingProgramAdmin(TrainingProgram program, int Area)
        {
            SetupCommonViewBagValues();

            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.PositionId = program.Position;
            ViewBag.AreaId = Area;

            Session["AreaId"] = Area;
            Session["PositionId"] = program.Position;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                int idPosition = program.Position;
                ViewBag.PositionSelected = context.Position.Find(idPosition).PositionName;
                List<TrainingProgram> listTrainingPrograms = context.TrainingProgram.Include("TrainingProgramCategory")
                                                                    .Where(x => x.Position == idPosition && x.Enable == true)
                                                                    .OrderBy(m => m.TrainingProgramCategory.Name).ToList();

                return View(listTrainingPrograms);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateTrainingProgram()
        {
            SetupCommonViewBagValues();

            try
            {
                string ida = Request.QueryString["ida"];
                string idp = Request.QueryString["idp"];

                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.PositionId = idp;
                ViewBag.AreaId = ida;

                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    List<TrainingProgramCategory> listCategories = context.TrainingProgramCategory.OrderBy(m => m.Name).ToList();
                    ViewBag.ListOfCategories = from category in listCategories
                                               select new { Text = category.Name, Value = category.IdTrainingProgramCategory };
                }
            }
            catch (Exception)
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.PositionId = 0;
                ViewBag.AreaId = 0;
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateTrainingProgram(TrainingProgram program, int Area, int Position)
        {
            SetupCommonViewBagValues();
            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");

            Session["AreaId"] = Area;
            Session["PositionId"] = Position;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                program.Enable = true;
                context.TrainingProgram.Add(program);
                context.SaveChanges();

                int lastId = (from record in context.TrainingProgram orderby record.IdTrainingProgram descending select record.IdTrainingProgram).First();

                var EmployeeByPosition = context.Employee.Where(x => x.CurrentPositionID == Position).ToList();

                foreach (Employee item in EmployeeByPosition)
                {
                    TrainingProgramDetails tpd = new TrainingProgramDetails();

                    tpd.IdTrainingProgramDetails = 0;
                    tpd.IdTrainingProgram = lastId;
                    tpd.Status = 0;
                    tpd.ResourceId = item.ResourceId;

                    context.TrainingProgramDetails.Add(tpd);
                    context.SaveChanges();
                }
            }

            return RedirectToAction("TrainingProgramAdmin");
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditTrainingProgram(int id)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                SetupCommonViewBagValues();
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");

                TrainingProgram program = context.TrainingProgram
                    .Include("Position1")
                    .Include("TrainingProgramCategory")
                    .Where(x => x.IdTrainingProgram == id)
                    .FirstOrDefault();

                if (program.StartDate == null)
                {
                    program.StartDate = DateTime.MinValue;
                }

                if (program.FinishDate == null)
                {
                    program.FinishDate = DateTime.MinValue;
                }

                List<TrainingProgramCategory> listCategories = context.TrainingProgramCategory.OrderBy(m => m.Name).ToList();
                ViewBag.ListOfCategories = from category in listCategories
                                           select new { Text = category.Name, Value = category.IdTrainingProgramCategory };

                ViewBag.PositionId = program.Position;
                return View(program);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditTrainingProgram(TrainingProgram program)
        {
            SetupCommonViewBagValues();
            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");

            Session["AreaId"] = program.Position1.AreaId;
            Session["PositionId"] = program.Position;

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                TrainingProgram instanceProgram = context.TrainingProgram.Find(program.IdTrainingProgram);
                instanceProgram.Link = program.Link;
                instanceProgram.Name = program.Name;
                instanceProgram.Points = program.Points;
                instanceProgram.Category = program.Category;
                instanceProgram.Position = program.Position;
                instanceProgram.StartDate = program.StartDate;
                instanceProgram.FinishDate = program.FinishDate;
                context.SaveChanges();

                var lstIdTrainingProgramDetails = context.TrainingProgramDetails.Where(x => x.IdTrainingProgram == program.IdTrainingProgram).ToList();

                foreach (var item in lstIdTrainingProgramDetails)
                {
                    context.Entry(item).State = EntityState.Modified;
                    context.SaveChanges();
                }

                return RedirectToAction("TrainingProgramAdmin");
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteTrainingProgram(int id)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                TrainingProgram program = context.TrainingProgram
                    .Include("Position1")
                    .Include("TrainingProgramCategory")
                    .Where(x => x.IdTrainingProgram == id)
                    .FirstOrDefault();

                Session["AreaId"] = program.Position1.AreaId;
                Session["PositionId"] = program.Position;

                return View(program);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteTrainingProgram(TrainingProgram program)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                ViewBag.PositionId = 0;
                ViewBag.AreaId = 0;

                TrainingProgram programToDelete = context.TrainingProgram.Find(program.IdTrainingProgram);
                programToDelete.Enable = false;
                context.Entry(programToDelete).State = EntityState.Modified;
                context.SaveChanges();

                return RedirectToAction("TrainingProgramAdmin");
            }
        }
        #endregion


        #region Training Program On Demand Admin

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult TrainingProgramOnDemandAdmin()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<TrainingProgramOnDemand> lstTrainings = context.TrainingProgramOnDemand.Where(x => x.Enable == true)
                                                                                            .OrderBy(m => m.StartDate).ToList();

                return View(lstTrainings);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult TrainingProgramOnDemandAdmin(TrainingProgram program)
        {
            SetupCommonViewBagValues();

            return RedirectToAction("CreateTrainingProgramOnDemand");
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateTrainingProgramOnDemand()
        {
            SetupCommonViewBagValues();

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateTrainingProgramOnDemand(TrainingProgramOnDemand tpod)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                if (ModelState.IsValid)
                {
                    tpod.Enable = true;
                    context.TrainingProgramOnDemand.Add(tpod);
                    context.SaveChanges();

                    return RedirectToAction("TrainingProgramOnDemandAdmin");
                }
                else
                {
                    ModelState.AddModelError("Error", "There is something wrong.");
                }
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditTrainingProgramOnDemand(int id)
        {
            SetupCommonViewBagValues();

            try
            {
                CDPTrackEntities context = new CDPTrackEntities();
                TrainingProgramOnDemand tpod = context.TrainingProgramOnDemand.Find(id);

                return View(tpod);
            }
            catch (Exception)
            {
                ModelState.AddModelError("Error", "There is something wrong.");

                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditTrainingProgramOnDemand(TrainingProgramOnDemand tpod)
        {
            SetupCommonViewBagValues();

            try
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Entry(tpod).State = EntityState.Modified;
                    context.SaveChanges();

                    return RedirectToAction("TrainingProgramOnDemandAdmin");
                }
            }
            catch (Exception)
            {
                ModelState.AddModelError("Error", "There is something wrong.");
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteTrainingProgramOnDemand(int id)
        {
            SetupCommonViewBagValues();

            try
            {
                CDPTrackEntities context = new CDPTrackEntities();
                TrainingProgramOnDemand tpod = context.TrainingProgramOnDemand.Find(id);

                return View(tpod);
            }
            catch (Exception)
            {
                ModelState.AddModelError("Error", "There is something wrong.");
            }

            return View();
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteTrainingProgramOnDemand(TrainingProgramOnDemand tpod)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                TrainingProgramOnDemand programToDelete = context.TrainingProgramOnDemand.Find(tpod.IdTrainingProgramOnDemand);
                programToDelete.Enable = false;
                context.Entry(programToDelete).State = EntityState.Modified;
                context.SaveChanges();

                return RedirectToAction("TrainingProgramOnDemandAdmin");
            }
        }

        #endregion

        #region General Training Program Admin

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult GeneralTrainingProgramAdmin()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<GeneralTrainingProgram> allGeneralProgramsList = context.GeneralTrainingProgram.Include("TrainingProgramCategory")
                                                                             .Where(x => x.Enabled)
                                                                             .OrderBy(m => m.TrainingProgramCategory.Name).ToList();
                return View(allGeneralProgramsList);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult CreateGeneralTrainingProgram()
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                List<TrainingProgramCategory> listCategories = context.TrainingProgramCategory.OrderBy(m => m.Name).ToList();
                ViewBag.ListOfCategories = from category in listCategories
                                           select new { Text = category.Name, Value = category.IdTrainingProgramCategory };

                return View();
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult CreateGeneralTrainingProgram(GeneralTrainingProgram generalProgram)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                generalProgram.Enabled = true;
                context.GeneralTrainingProgram.Add(generalProgram);
                context.SaveChanges();

                int idGeneralProgram = generalProgram.IdGeneralTrainingProgram;
                foreach (var resource in context.Resources)
                {

                    GeneralTrainingProgramDetails TrainingProgramDetail = new GeneralTrainingProgramDetails();
                    TrainingProgramDetail.IdGeneralTrainingProgram = idGeneralProgram;
                    TrainingProgramDetail.ResourceId = resource.ResourceId;
                    TrainingProgramDetail.Status = 0;

                    context.GeneralTrainingProgramDetails.Add(TrainingProgramDetail);
                }

                context.SaveChanges();
            }

            return RedirectToAction("GeneralTrainingProgramAdmin");
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult DeleteGeneralTrainingProgram(int id)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                GeneralTrainingProgram generalTrainingProgram = context.GeneralTrainingProgram.Include("TrainingProgramCategory").Where(x => x.IdGeneralTrainingProgram == id).FirstOrDefault();
                return View(generalTrainingProgram);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult DeleteGeneralTrainingProgram(GeneralTrainingProgram program)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                GeneralTrainingProgram generalTP = context.GeneralTrainingProgram.Find(program.IdGeneralTrainingProgram);
                generalTP.Enabled = false;

                context.SaveChanges();

                return RedirectToAction("GeneralTrainingProgramAdmin");
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        public ActionResult EditGeneralTrainingProgram(int id)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                GeneralTrainingProgram generalTrainingProgram = context.GeneralTrainingProgram.Include("TrainingProgramCategory").Where(x => x.IdGeneralTrainingProgram == id).FirstOrDefault();

                if (generalTrainingProgram.StartDate == null)
                {
                    generalTrainingProgram.StartDate = DateTime.MinValue;
                }

                if (generalTrainingProgram.FinishDate == null)
                {
                    generalTrainingProgram.FinishDate = DateTime.MinValue;
                }

                List<TrainingProgramCategory> listCategories = context.TrainingProgramCategory.OrderBy(m => m.Name).ToList();
                ViewBag.ListOfCategories = from category in listCategories
                                           select new { Text = category.Name, Value = category.IdTrainingProgramCategory };

                return View(generalTrainingProgram);
            }
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditGeneralTrainingProgram(GeneralTrainingProgram program)
        {
            SetupCommonViewBagValues();

            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                GeneralTrainingProgram generalTrainingProgram = context.GeneralTrainingProgram.Where(x => x.IdGeneralTrainingProgram == program.IdGeneralTrainingProgram).FirstOrDefault();
                generalTrainingProgram.Link = program.Link;
                generalTrainingProgram.Name = program.Name;
                generalTrainingProgram.Points = program.Points;
                generalTrainingProgram.Category = program.Category;
                generalTrainingProgram.StartDate = program.StartDate;
                generalTrainingProgram.FinishDate = program.FinishDate;
                context.SaveChanges();

                return RedirectToAction("GeneralTrainingProgramAdmin");
            }
        }

        #endregion


        #region Skill Compass Glossary

#if !DEBUG
                [RoleAuthorization(Role.TalentManagement)]
#endif
        //Skill compass Glossary Home for Admin
        public ActionResult SkillCompassGlossary()
        {
            SetupCommonViewBagValues();
            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.AreaId = 0;
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                var fullGlossary = context.SkillCompassGlossary.Include("Area").OrderBy(x => x.Name).ToList();
                return View(fullGlossary);
            }
        }

        //when selecting an Area
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult SkillCompassGlossary(List<SkillCompassGlossary> position, int Area)
        {
            SetupCommonViewBagValues();
            try
            {
                ViewBag.AreaId = Area;
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", Area);

                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Configuration.LazyLoadingEnabled = false;
                    // glossary by Area
                    var glossarybyArea = context.SkillCompassGlossary.Include("Area").Where(x => x.AreaId == Area).OrderBy(x => x.Name).ToList();
                    ViewBag.Area = glossarybyArea.FirstOrDefault().Area.Name.ToString();
                    position = glossarybyArea;
                }
            }
            catch (Exception)
            {
                position = null;
            }
            return View(position);
        }
#if !DEBUG
                [RoleAuthorization(Role.TalentManagement)]
#endif
        // ActionResult for create new Skill on SCG (Skill Compass Glossary)
        public ActionResult CreateSkillCompassGlossary()
        {
            SetupCommonViewBagValues();
            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
            ViewBag.error = "";
            return View();
        }
#if !DEBUG
                [RoleAuthorization(Role.TalentManagement)]
#endif
        //ActionResult for Create new Skill on SCG with POST request
        [HttpPost]
        public ActionResult CreateSkillCompassGlossary(int Area, string Name, string Description)
        {
            SkillCompassGlossary skillcompassglossary = new SkillCompassGlossary();
            skillcompassglossary.AreaId = Area;
            skillcompassglossary.Name = Name;
            skillcompassglossary.Description = Description;
            SetupCommonViewBagValues();
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                if (ModelState.IsValid)
                {
                    context.SkillCompassGlossary.Add(skillcompassglossary);
                    context.SaveChanges();
                    return RedirectToAction("SkillCompassGlossary");
                }
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name");
                return View();
            }

        }
#if !DEBUG
                [RoleAuthorization(Role.TalentManagement)]
#endif
        // Action Result for DELETE a Skill on SCG
        public ActionResult DeleteSkillCompassGlossary(int id)
        {
            SetupCommonViewBagValues();
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                SkillCompassGlossary skill = context.SkillCompassGlossary.Include("Area")
                                                .Where(x => x.SkillCompassGlossaryId == id).FirstOrDefault();
                return View(skill);
            }
        }
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        // Action Result Confirmed Post request
        [HttpPost, ActionName("DeleteSkillCompassGlossary")]
        public ActionResult DeleteSkillCompassGlossarConfirmed(int id)
        {
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                SkillCompassGlossary SCG = context.SkillCompassGlossary.Find(id);
                context.SkillCompassGlossary.Remove(SCG);
                context.SaveChanges();
            }
            return RedirectToAction("SkillCompassGlossary");
        }
#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        // Action Result to Edit a Skill 
        public ActionResult EditSkillCompassGlossary(int id)
        {
            SetupCommonViewBagValues();
            SkillCompassGlossary SCG = new SkillCompassGlossary();
            using (CDPTrackEntities context = new CDPTrackEntities())
            {
                SCG = context.SkillCompassGlossary.Find(id);
                ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", SCG.AreaId);
            }
            return View(SCG);
        }

#if !DEBUG
        [RoleAuthorization(Role.TalentManagement)]
#endif
        [HttpPost]
        public ActionResult EditSkillCompassGlossary(SkillCompassGlossary SCG)
        {
            SetupCommonViewBagValues();
            if (ModelState.IsValid)
            {
                using (CDPTrackEntities context = new CDPTrackEntities())
                {
                    context.Entry(SCG).State = EntityState.Modified;
                    context.SaveChanges();
                }
                return RedirectToAction("SkillCompassGlossary");
            }
            ViewBag.ListOfAreas = new SelectList(GetArea(), "AreaId", "Name", SCG.AreaId);
            return View(SCG);
        }

        #endregion


        #endregion

        /************************************************************Region for Action Results "Help Area"  **********************************/
        #region Help

        public ActionResult Help()
        {
            SetupCommonViewBagValues();
            return View();
        }

        public ActionResult About()
        {
            SetupCommonViewBagValues();
            return View();
        }

        #endregion
    }
}