﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using CDPTrackerSite.DataAccessor;
using Utils;

namespace CDPTrackerSite.RoleManagement
{
    public enum Role
    {
        Executive,
        TalentManagement,
        Manager,
        Employee,
    }

    public class RoleManagementHelper
    {
        private static readonly Dictionary<Role, string[]> RolePermissions = new Dictionary<Role, string[]>
                                                                         {
                                                                             {Role.Executive, new []{"tdg-moss-executives"}},
                                                                             {Role.TalentManagement, new []{"tdg-moss-talent management"}},
                                                                             {Role.Manager, new []{"tdg-moss-pm", "Manager Level Access"}},
                                                                             {Role.Employee, new []{"tdg-moss-td"}},
                                                                         };

        public static bool UserIsInRole(IPrincipal user, Role role)
        {
            string[] groups;
            if (!RolePermissions.TryGetValue(role, out groups))
            {
                return false;
            }
            if (role == Role.Manager)
            {
                //direct validation for user as manager to handle the Tripwire Srs case
                return groups.Any(user.IsInRole) || UserIsManager(user);
            }

            return groups.Any(user.IsInRole);
        }
        private static bool UserIsManager(IPrincipal user)
        {
            return ResourceDataAccessor.IsManager(user.Identity.Name.StripDomain());
        }
    }
}