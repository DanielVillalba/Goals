﻿namespace Utils
{
    public class Constants
    {
        public static readonly string[] ExcludedOperationUnits = new[] { "Ex-User", "Interns" };
    }
}
