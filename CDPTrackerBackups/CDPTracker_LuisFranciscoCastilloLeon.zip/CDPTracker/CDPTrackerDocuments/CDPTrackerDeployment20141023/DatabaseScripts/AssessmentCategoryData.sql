USE [CDPTrack]
GO
SET IDENTITY_INSERT [dbo].[AssessmentCategory] ON 

GO
INSERT [dbo].[AssessmentCategory] ([AssessmentCategoryId], [Name]) VALUES (1, N'Software Technology Skills')
GO
INSERT [dbo].[AssessmentCategory] ([AssessmentCategoryId], [Name]) VALUES (2, N'Software Engineering Skills')
GO
INSERT [dbo].[AssessmentCategory] ([AssessmentCategoryId], [Name]) VALUES (3, N'Leadership, Management and Soft Skills')
GO
SET IDENTITY_INSERT [dbo].[AssessmentCategory] OFF
GO
