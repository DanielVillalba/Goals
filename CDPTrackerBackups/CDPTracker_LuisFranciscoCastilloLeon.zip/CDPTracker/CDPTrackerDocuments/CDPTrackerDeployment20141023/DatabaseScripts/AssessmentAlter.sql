USE [CDPTrack]

ALTER TABLE Assessment ADD DateCreated DATE NOT NULL