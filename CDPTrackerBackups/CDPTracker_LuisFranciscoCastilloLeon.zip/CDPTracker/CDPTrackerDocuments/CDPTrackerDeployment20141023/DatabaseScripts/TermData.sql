USE [CDPTrack]
GO
SET IDENTITY_INSERT [dbo].[Term] ON 

GO
INSERT [dbo].[Term] ([TermId], [Name]) VALUES (1, N'Short Term')
GO
INSERT [dbo].[Term] ([TermId], [Name]) VALUES (2, N'Long Term')
GO
SET IDENTITY_INSERT [dbo].[Term] OFF
GO
