Run the scripts in the following order:
GoalsView
Area
Area Data
Position
Note: Before insert position data, needs to be removed FK_Position_Position
Then run the PositionData script and
add the foreing key again througout the database diagram
PositionData
Employee
Objective
Category
GoalTracking


Position must have 'is entity' enabled.

Run ObjectiveInsert script.

Run ObjectiveAlter script.

Run ResourceAlter script.

/***************************END FIRST PACKAGE********************************/
