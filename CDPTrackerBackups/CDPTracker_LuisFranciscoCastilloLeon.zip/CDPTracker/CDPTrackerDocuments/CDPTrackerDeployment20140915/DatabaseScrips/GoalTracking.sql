USE [CDPTrack]
GO

ALTER TABLE [dbo].[GoalTracking]
   ADD ObjectiveId int
GO

