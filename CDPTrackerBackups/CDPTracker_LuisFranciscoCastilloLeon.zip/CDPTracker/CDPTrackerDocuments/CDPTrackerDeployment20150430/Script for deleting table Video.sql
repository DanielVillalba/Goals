USE CDPTrack

DROP TABLE GeneralTrainingProgramVideo

DROP TABLE TrainingProgramVideo