USE [CDPTrack]

ALTER TABLE GeneralTrainingProgram ADD Enabled bit NOT NULL Default 'True'