USE [CDPTrack]

ALTER TABLE TrainingProgram ADD Enable BIT default 'True'