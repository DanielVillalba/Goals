USE [CDPTrack]
GO

ALTER TABLE [dbo].[Area]
ADD ImageCareerPath VARCHAR(1000) NULL,
    ImageSkillCompass VARCHAR(1000) NULL