﻿namespace CDPEmailNotification
{
    class PendingActions
    {
        public string EmployeName { get; set; }
        public int PendingActionCount { get; set; }
    }
}
